import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import ForgotPassword from './pages/ForgotPassword';
import ResetPassword from './pages/ResetPassword';
import EmailConfirmation from './pages/EmailConfirmation';
import VerificationCode from './pages/VerificationCode';
import AgentDetail from './pages/AgentDetail';
import Terms from './pages/Terms';
import Settings from './pages/Settings';
import Help from './pages/Help';
import Analytics from './pages/Analytics';
import MyAgents from './pages/MyAgents';
import Payment from './pages/Payment';
import PaymentSuccess from './pages/PaymentSuccess';
import AgentSetup from './pages/AgentSetup';
import Template from './pages/Template';
import Purchase from './pages/Purchase';
import Error404 from './pages/errors/Error404';
import Error403 from './pages/errors/Error403';
import Error500 from './pages/errors/Error500';

function AppContent() {
  const [isDark, setIsDark] = useState(true);
  const location = useLocation();

  const isAuthPage = (pathname: string) => {
    const authPages = ['/login', '/register', '/forgot-password', '/reset-password', '/email-confirmation', '/verification-code'];
    return authPages.some(page => pathname.startsWith(page));
  };

  const isSimplePage = (pathname: string) => {
    return pathname === '/terms' || pathname.startsWith('/payment') || pathname === '/payment-success';
  };

  const isErrorPage = (pathname: string) => {
    return ['/404', '/403', '/500'].includes(pathname);
  };

  const isAgentSetup = location.pathname === '/agent-setup';

  const shouldShowSidebar = !isAuthPage(location.pathname) && !isSimplePage(location.pathname) && !isAgentSetup && !isErrorPage(location.pathname);
  const shouldShowHeader = !isAuthPage(location.pathname) && !isSimplePage(location.pathname) && !isAgentSetup && !isErrorPage(location.pathname);
  const shouldShowFooter = !isAuthPage(location.pathname) && !isSimplePage(location.pathname) && !isAgentSetup && !isErrorPage(location.pathname);

  return (
    <div className={`min-h-screen flex flex-col ${isDark ? 'bg-[#0B1121]' : 'bg-[#f8f8f8]'}`}>
      <div className={`flex-1 ${isDark ? 'bg-grid-pattern' : 'bg-grid-pattern-light'}`}>
        {shouldShowSidebar && <Sidebar isDark={isDark} />}
        {shouldShowHeader && <Header isDark={isDark} toggleTheme={() => setIsDark(!isDark)} />}
        
        <Routes>
          <Route path="/" element={<Navigate to="/home" replace />} />
          <Route path="/home" element={<Home isDark={isDark} />} />
          <Route path="/agents" element={<MyAgents isDark={isDark} />} />
          <Route path="/analytics" element={<Analytics isDark={isDark} />} />
          <Route path="/login" element={<Login isDark={isDark} toggleTheme={() => setIsDark(!isDark)} />} />
          <Route path="/register" element={<Register isDark={isDark} toggleTheme={() => setIsDark(!isDark)} />} />
          <Route path="/forgot-password" element={<ForgotPassword isDark={isDark} toggleTheme={() => setIsDark(!isDark)} />} />
          <Route path="/verification-code" element={<VerificationCode isDark={isDark} toggleTheme={() => setIsDark(!isDark)} />} />
          <Route path="/reset-password" element={<ResetPassword isDark={isDark} toggleTheme={() => setIsDark(!isDark)} />} />
          <Route path="/email-confirmation" element={<EmailConfirmation isDark={isDark} toggleTheme={() => setIsDark(!isDark)} />} />
          <Route path="/agent/:id" element={<AgentDetail isDark={isDark} />} />
          <Route path="/payment/:id" element={<Payment isDark={isDark} />} />
          <Route path="/payment-success" element={<PaymentSuccess isDark={isDark} />} />
          <Route path="/agent-setup" element={<AgentSetup isDark={isDark} />} />
          <Route path="/terms" element={<Terms isDark={isDark} />} />
          <Route path="/settings" element={<Settings isDark={isDark} />} />
          <Route path="/help" element={<Help isDark={isDark} />} />
          <Route path="/template" element={<Template isDark={isDark} />} />
          <Route path="/purchase" element={<Purchase isDark={isDark} />} />
          
          {/* Error Pages */}
          <Route path="/404" element={<Error404 isDark={isDark} />} />
          <Route path="/403" element={<Error403 isDark={isDark} />} />
          <Route path="/500" element={<Error500 isDark={isDark} />} />
          <Route path="*" element={<Error404 isDark={isDark} />} />
        </Routes>

        {shouldShowFooter && <Footer isDark={isDark} />}
      </div>
    </div>
  );
}

export default function App() {
  return (
    <Router>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </Router>
  );
}