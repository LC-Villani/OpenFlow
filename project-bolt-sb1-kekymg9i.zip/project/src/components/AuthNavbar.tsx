import React from 'react';
import { Link } from 'react-router-dom';
import { X, HelpCircle, Globe, Sun, Moon } from 'lucide-react';

interface AuthNavbarProps {
  isDark: boolean;
  toggleTheme: () => void;
}

export default function AuthNavbar({ isDark, toggleTheme }: AuthNavbarProps) {
  return (
    <nav className={`fixed top-0 left-0 right-0 h-16 ${isDark ? 'bg-[#1A1F2E]' : 'bg-white'} border-b ${isDark ? 'border-purple-500/10' : 'border-purple-100'} z-50`}>
      <div className="container mx-auto h-full px-6 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-3 group">
          <div className="relative">
            <div className={`w-10 h-10 ${isDark ? 'bg-[#6D28D9]' : 'bg-purple-500'} rounded-xl flex items-center justify-center overflow-hidden`}>
              <X className="w-6 h-6 text-white relative z-10 group-hover:rotate-180 transition-transform duration-700" />
            </div>
            <div className={`absolute -inset-1 ${isDark ? 'bg-purple-500' : 'bg-purple-200'} rounded-xl blur opacity-30 group-hover:opacity-60 transition-opacity`}></div>
          </div>
          <div className="flex items-center">
            <span className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-gray-900'} tracking-tight group-hover:text-purple-400 transition-colors duration-300`}>
              Open
            </span>
            <span className={`text-2xl font-bold ${isDark ? 'text-[#7C3AED]' : 'text-purple-500'} tracking-tight relative`}>
              Flow
            </span>
          </div>
        </Link>

        <div className="flex items-center gap-4">
          <button
            className={`p-2 rounded-xl ${isDark ? 'hover:bg-white/5' : 'hover:bg-gray-100'} transition-colors duration-300`}
            title="Ajuda"
          >
            <HelpCircle className={`w-5 h-5 ${isDark ? 'text-purple-400' : 'text-purple-500'}`} />
          </button>

          <button
            className={`p-2 rounded-xl ${isDark ? 'hover:bg-white/5' : 'hover:bg-gray-100'} transition-colors duration-300`}
            title="Idioma"
          >
            <Globe className={`w-5 h-5 ${isDark ? 'text-purple-400' : 'text-purple-500'}`} />
          </button>

          <button
            onClick={toggleTheme}
            className={`p-2 rounded-xl ${isDark ? 'hover:bg-white/5' : 'hover:bg-gray-100'} transition-colors duration-300`}
            title={isDark ? 'Modo claro' : 'Modo escuro'}
          >
            {isDark ? (
              <Sun className="w-5 h-5 text-purple-400" />
            ) : (
              <Moon className="w-5 h-5 text-purple-500" />
            )}
          </button>
        </div>
      </div>
    </nav>
  );
}