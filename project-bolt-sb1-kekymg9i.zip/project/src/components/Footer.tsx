import React from 'react';
import { Link } from 'react-router-dom';
import { X } from 'lucide-react';

interface FooterProps {
  isDark: boolean;
}

export default function Footer({ isDark }: FooterProps) {
  const footerSections = [
    {
      title: 'Produtos',
      links: [
        { label: 'Assistente IA', href: '/products/ai-assistant' },
        { label: 'Qualificação de Leads', href: '/products/lead-qualification' },
        { label: 'Dashboard Analítico', href: '/products/analytics' },
        { label: 'Colaboração em Equipe', href: '/products/team' },
      ],
    },
    {
      title: 'Empresa',
      links: [
        { label: 'Sobre Nós', href: '/about' },
        { label: 'Carreiras', href: '/careers' },
        { label: 'Blog', href: '/blog' },
        { label: 'Contato', href: '/contact' },
      ],
    },
    {
      title: 'Legal',
      links: [
        { label: 'Política de Privacidade', href: '/privacy' },
        { label: 'Termos de Serviço', href: '/terms' },
        { label: 'Política de Cookies', href: '/cookies' },
      ],
    },
  ];

  return (
    <footer className={`${isDark ? 'bg-[#0B1121]' : 'bg-[#f8f8f8]'} border-t ${isDark ? 'border-purple-500/10' : 'border-purple-100'} mt-auto`}>
      <div className="container mx-auto px-4 md:px-6 py-8 md:py-12 md:ml-64">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 md:gap-12">
          <div>
            <Link to="/" className="flex items-center gap-3 group">
              <div className="relative">
                <div className={`w-10 h-10 ${isDark ? 'bg-[#6D28D9]' : 'bg-purple-500'} rounded-xl flex items-center justify-center overflow-hidden`}>
                  <X className="w-6 h-6 text-white relative z-10 group-hover:rotate-180 transition-transform duration-700" />
                </div>
              </div>
              <div className="flex items-center">
                <span className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>Open</span>
                <span className={`text-2xl font-bold ${isDark ? 'text-[#7C3AED]' : 'text-purple-500'}`}>Flow</span>
              </div>
            </Link>
            <p className={`mt-4 text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
              Revolucionando a geração de leads com soluções alimentadas por IA.
            </p>
          </div>

          {footerSections.map((section, index) => (
            <div key={index}>
              <h3 className={`text-lg font-semibold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
                {section.title}
              </h3>
              <ul className="space-y-2">
                {section.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <Link
                      to={link.href}
                      className={`text-sm ${isDark ? 'text-purple-300 hover:text-purple-200' : 'text-purple-600 hover:text-purple-700'} transition-colors duration-300`}
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-8 md:mt-12 pt-8 border-t border-purple-500/10">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
              © 2025 OpenFlow. Todos os direitos reservados.
            </p>
            <div className="flex items-center gap-4 md:gap-6">
              <a href="https://google.com" target="_blank" rel="noopener noreferrer" className="hover:opacity-80 transition-opacity">
                <img src="https://www.google.com/favicon.ico" alt="Google" className="w-5 h-5" />
              </a>
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="hover:opacity-80 transition-opacity">
                <img src="https://www.facebook.com/favicon.ico" alt="Facebook" className="w-5 h-5" />
              </a>
              <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="hover:opacity-80 transition-opacity">
                <img src="https://www.linkedin.com/favicon.ico" alt="LinkedIn" className="w-5 h-5" />
              </a>
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="hover:opacity-80 transition-opacity">
                <img src="https://twitter.com/favicon.ico" alt="Twitter" className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}