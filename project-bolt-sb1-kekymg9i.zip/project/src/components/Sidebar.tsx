import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Home, 
  ShoppingBag, 
  Settings, 
  HelpCircle,
  BarChart3,
  X,
  Menu
} from 'lucide-react';

interface SidebarProps {
  isDark: boolean;
}

export default function Sidebar({ isDark }: SidebarProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  const menuItems = [
    { icon: Home, label: 'Início', path: '/home' },
    { icon: ShoppingBag, label: 'Meus Agentes', path: '/agents' },
    { icon: BarChart3, label: 'Analytics', path: '/analytics' },
    { icon: Settings, label: 'Configurações', path: '/settings' },
    { icon: HelpCircle, label: 'Ajuda', path: '/help' },
  ];

  return (
    <>
      {/* Mobile Menu Button */}
      <button
        onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        className={`md:hidden fixed top-4 left-4 z-50 p-2 rounded-lg ${
          isDark ? 'bg-[#232838] text-purple-400' : 'bg-purple-50 text-purple-500'
        } hover:bg-opacity-80 transition-colors duration-300`}
      >
        <Menu className="w-6 h-6" />
      </button>

      {/* Sidebar */}
      <div className={`
        fixed top-0 left-0 h-screen bg-opacity-95 backdrop-blur-sm transition-transform duration-300 z-40
        ${isDark ? 'bg-[#1A1F2E]' : 'bg-white'} 
        border-r ${isDark ? 'border-purple-500/10' : 'border-purple-100'}
        md:translate-x-0 md:w-64
        ${isMobileMenuOpen ? 'w-64 translate-x-0' : 'w-64 -translate-x-full'}
      `}>
        <div className="p-6">
          <Link to="/home" className="flex items-center gap-3 group">
            <div className="relative">
              <div className={`w-10 h-10 ${isDark ? 'bg-[#6D28D9]' : 'bg-purple-500'} rounded-xl flex items-center justify-center overflow-hidden`}>
                <X className="w-6 h-6 text-white relative z-10 group-hover:rotate-180 transition-transform duration-700" />
              </div>
              <div className={`absolute -inset-1 ${isDark ? 'bg-purple-500' : 'bg-purple-200'} rounded-xl blur opacity-30 group-hover:opacity-60 transition-opacity`}></div>
            </div>
            <div className="flex items-center">
              <span className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-gray-900'} tracking-tight group-hover:text-purple-400 transition-colors duration-300`}>
                Open
              </span>
              <span className={`text-2xl font-bold ${isDark ? 'text-[#7C3AED]' : 'text-purple-500'} tracking-tight relative`}>
                Flow
              </span>
            </div>
          </Link>
        </div>

        <nav className="mt-6 flex-1">
          {menuItems.map((item, index) => (
            <Link
              key={index}
              to={item.path}
              onClick={() => setIsMobileMenuOpen(false)}
              className={`flex items-center gap-3 px-6 py-3 ${isDark ? 'hover:bg-purple-500/10' : 'hover:bg-purple-50'} transition-colors duration-300 group`}
            >
              <item.icon className={`w-5 h-5 ${isDark ? 'text-purple-400' : 'text-purple-500'} group-hover:text-purple-500 transition-colors duration-300`} />
              <span className={`${isDark ? 'text-purple-100' : 'text-gray-700'} group-hover:text-purple-500 transition-colors duration-300`}>
                {item.label}
              </span>
            </Link>
          ))}
        </nav>
      </div>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-30 md:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}
    </>
  );
}