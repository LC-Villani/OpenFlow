import React, { useState } from 'react';
import { User, Mail, Phone, Trash2, AlertCircle, Edit2, Check, X as XIcon } from 'lucide-react';

interface SettingsProps {
  isDark: boolean;
}

type EditingField = 'name' | 'email' | 'phone' | null;

export default function Settings({ isDark }: SettingsProps) {
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [showVerificationModal, setShowVerificationModal] = useState(false);
  const [verificationCode, setVerificationCode] = useState(['', '', '', '', '', '']);
  const [editingField, setEditingField] = useState<EditingField>(null);
  const [isLoading, setIsLoading] = useState(false);
  
  // Valores atuais
  const [name, setName] = useState('João Silva');
  const [email, setEmail] = useState('joao@example.com');
  const [phone, setPhone] = useState('(11) 99999-9999');
  
  // Valores temporários para edição
  const [tempEmail, setTempEmail] = useState(email);
  const [tempPhone, setTempPhone] = useState(phone);
  const [tempName, setTempName] = useState(name);

  const handleEdit = (field: EditingField) => {
    setEditingField(field);
    if (field === 'email') setTempEmail(email);
    if (field === 'phone') setTempPhone(phone);
    if (field === 'name') setTempName(name);
  };

  const handleCancel = () => {
    setEditingField(null);
    setTempEmail(email);
    setTempPhone(phone);
    setTempName(name);
  };

  const handleSave = (field: EditingField) => {
    if (field === 'name') {
      setName(tempName);
      setEditingField(null);
    } else if (field === 'email' || field === 'phone') {
      setShowVerificationModal(true);
    }
  };

  const handleVerificationSubmit = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      setShowVerificationModal(false);
      if (editingField === 'email') setEmail(tempEmail);
      if (editingField === 'phone') setPhone(tempPhone);
      setEditingField(null);
      setVerificationCode(['', '', '', '', '', '']);
    }, 2000);
  };

  return (
    <div className="min-h-screen pt-24 pb-12 pl-72 pr-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-12">
          <h1 className={`text-4xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
            Configurações da Conta
          </h1>
          <p className={`text-xl ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
            Gerencie suas informações pessoais e preferências
          </p>
        </div>

        <div className="space-y-6">
          {/* Informações Pessoais */}
          <div className={`p-6 rounded-2xl ${isDark ? 'bg-[#1A1F2E]' : 'bg-white'} space-y-6`}>
            <h2 className={`text-2xl font-semibold ${isDark ? 'text-white' : 'text-gray-900'}`}>
              Informações Pessoais
            </h2>

            <div className="space-y-4">
              {/* Nome */}
              <div className="space-y-2">
                <label className={`block text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
                  Nome Completo
                </label>
                <div className="relative flex items-center">
                  <input
                    type="text"
                    value={editingField === 'name' ? tempName : name}
                    onChange={(e) => setTempName(e.target.value)}
                    disabled={editingField !== 'name'}
                    className={`w-full pl-4 pr-24 py-3 ${isDark ? 'bg-[#232838]' : 'bg-purple-50'} rounded-xl ${isDark ? 'text-white' : 'text-gray-900'} focus:outline-none focus:ring-2 ${isDark ? 'focus:ring-purple-500/30' : 'focus:ring-purple-500/50'} transition-all duration-300 disabled:opacity-50`}
                  />
                  <div className="absolute right-2 flex items-center gap-2">
                    {editingField === 'name' ? (
                      <>
                        <button
                          onClick={() => handleSave('name')}
                          className="p-2 text-green-500 hover:bg-green-500/10 rounded-lg transition-colors duration-300"
                        >
                          <Check size={20} />
                        </button>
                        <button
                          onClick={handleCancel}
                          className="p-2 text-red-500 hover:bg-red-500/10 rounded-lg transition-colors duration-300"
                        >
                          <XIcon size={20} />
                        </button>
                      </>
                    ) : (
                      <button
                        onClick={() => handleEdit('name')}
                        className={`p-2 ${isDark ? 'text-purple-400 hover:bg-purple-500/10' : 'text-purple-500 hover:bg-purple-100'} rounded-lg transition-colors duration-300`}
                      >
                        <Edit2 size={20} />
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Email */}
              <div className="space-y-2">
                <label className={`block text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
                  Email
                </label>
                <div className="relative flex items-center">
                  <input
                    type="email"
                    value={editingField === 'email' ? tempEmail : email}
                    onChange={(e) => setTempEmail(e.target.value)}
                    disabled={editingField !== 'email'}
                    className={`w-full pl-4 pr-24 py-3 ${isDark ? 'bg-[#232838]' : 'bg-purple-50'} rounded-xl ${isDark ? 'text-white' : 'text-gray-900'} focus:outline-none focus:ring-2 ${isDark ? 'focus:ring-purple-500/30' : 'focus:ring-purple-500/50'} transition-all duration-300 disabled:opacity-50`}
                  />
                  <div className="absolute right-2 flex items-center gap-2">
                    {editingField === 'email' ? (
                      <>
                        <button
                          onClick={() => handleSave('email')}
                          className="p-2 text-green-500 hover:bg-green-500/10 rounded-lg transition-colors duration-300"
                        >
                          <Check size={20} />
                        </button>
                        <button
                          onClick={handleCancel}
                          className="p-2 text-red-500 hover:bg-red-500/10 rounded-lg transition-colors duration-300"
                        >
                          <XIcon size={20} />
                        </button>
                      </>
                    ) : (
                      <button
                        onClick={() => handleEdit('email')}
                        className={`p-2 ${isDark ? 'text-purple-400 hover:bg-purple-500/10' : 'text-purple-500 hover:bg-purple-100'} rounded-lg transition-colors duration-300`}
                      >
                        <Edit2 size={20} />
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Telefone */}
              <div className="space-y-2">
                <label className={`block text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
                  Telefone
                </label>
                <div className="relative flex items-center">
                  <input
                    type="tel"
                    value={editingField === 'phone' ? tempPhone : phone}
                    onChange={(e) => setTempPhone(e.target.value)}
                    disabled={editingField !== 'phone'}
                    className={`w-full pl-4 pr-24 py-3 ${isDark ? 'bg-[#232838]' : 'bg-purple-50'} rounded-xl ${isDark ? 'text-white' : 'text-gray-900'} focus:outline-none focus:ring-2 ${isDark ? 'focus:ring-purple-500/30' : 'focus:ring-purple-500/50'} transition-all duration-300 disabled:opacity-50`}
                  />
                  <div className="absolute right-2 flex items-center gap-2">
                    {editingField === 'phone' ? (
                      <>
                        <button
                          onClick={() => handleSave('phone')}
                          className="p-2 text-green-500 hover:bg-green-500/10 rounded-lg transition-colors duration-300"
                        >
                          <Check size={20} />
                        </button>
                        <button
                          onClick={handleCancel}
                          className="p-2 text-red-500 hover:bg-red-500/10 rounded-lg transition-colors duration-300"
                        >
                          <XIcon size={20} />
                        </button>
                      </>
                    ) : (
                      <button
                        onClick={() => handleEdit('phone')}
                        className={`p-2 ${isDark ? 'text-purple-400 hover:bg-purple-500/10' : 'text-purple-500 hover:bg-purple-100'} rounded-lg transition-colors duration-300`}
                      >
                        <Edit2 size={20} />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Exclusão de Conta */}
          <div className={`p-6 rounded-2xl ${isDark ? 'bg-[#1A1F2E]' : 'bg-white'}`}>
            <h2 className={`text-2xl font-semibold ${isDark ? 'text-white' : 'text-gray-900'} mb-4`}>
              Excluir Conta
            </h2>
            
            <p className={`${isDark ? 'text-purple-300' : 'text-purple-600'} mb-6`}>
              Ao excluir sua conta, todos os seus dados serão permanentemente removidos. Esta ação não pode ser desfeita.
            </p>

            {!showDeleteConfirm ? (
              <button
                onClick={() => setShowDeleteConfirm(true)}
                className="px-6 py-3 bg-red-500 text-white rounded-xl hover:bg-red-600 transition-all duration-300 flex items-center gap-2"
              >
                <Trash2 size={20} />
                <span>Excluir Minha Conta</span>
              </button>
            ) : (
              <div className={`p-4 rounded-xl ${isDark ? 'bg-red-500/10' : 'bg-red-50'} space-y-4`}>
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-6 h-6 text-red-500 flex-shrink-0 mt-1" />
                  <div>
                    <h3 className={`font-semibold ${isDark ? 'text-white' : 'text-gray-900'} mb-2`}>
                      Tem certeza que deseja excluir sua conta?
                    </h3>
                    <p className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
                      Esta ação é irreversível e todos os seus dados serão perdidos.
                    </p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <button
                    onClick={() => setShowDeleteConfirm(false)}
                    className={`px-4 py-2 rounded-lg ${isDark ? 'bg-[#232838] text-purple-300 hover:bg-[#2A303F]' : 'bg-purple-50 text-purple-600 hover:bg-purple-100'} transition-all duration-300`}
                  >
                    Cancelar
                  </button>
                  <button className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-all duration-300">
                    Confirmar Exclusão
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Modal de Verificação */}
      {showVerificationModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className={`w-full max-w-md p-6 rounded-2xl ${isDark ? 'bg-[#1A1F2E]' : 'bg-white'}`}>
            <h3 className={`text-xl font-semibold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
              Verificação de {editingField === 'email' ? 'Email' : 'Telefone'}
            </h3>
            <p className={`mb-6 ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
              Digite o código de verificação enviado para seu {editingField === 'email' ? 'email' : 'telefone'}
            </p>

            <div className="flex justify-center gap-2 mb-6">
              {verificationCode.map((digit, index) => (
                <input
                  key={index}
                  type="text"
                  maxLength={1}
                  value={digit}
                  onChange={(e) => {
                    const newCode = [...verificationCode];
                    newCode[index] = e.target.value;
                    setVerificationCode(newCode);
                  }}
                  className={`w-12 h-14 text-center text-xl font-semibold ${
                    isDark ? 'bg-[#232838] text-white' : 'bg-purple-50 text-gray-900'
                  } rounded-xl focus:outline-none focus:ring-2 ${
                    isDark ? 'focus:ring-purple-500/30' : 'focus:ring-purple-500/50'
                  } transition-all duration-300`}
                />
              ))}
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => {
                  setShowVerificationModal(false);
                  handleCancel();
                }}
                className={`flex-1 px-4 py-3 rounded-xl ${
                  isDark ? 'bg-[#232838] text-purple-300 hover:bg-[#2A303F]' : 'bg-purple-50 text-purple-600 hover:bg-purple-100'
                } transition-all duration-300`}
              >
                Cancelar
              </button>
              <button
                onClick={handleVerificationSubmit}
                disabled={isLoading || verificationCode.some(digit => !digit)}
                className="flex-1 px-4 py-3 bg-purple-500 text-white rounded-xl hover:bg-purple-600 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isLoading ? 'Verificando...' : 'Verificar'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}