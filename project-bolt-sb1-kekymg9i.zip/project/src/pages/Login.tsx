import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Mail, Lock, ArrowRight } from 'lucide-react';
import AuthNavbar from '../components/AuthNavbar';

interface LoginProps {
  isDark: boolean;
  toggleTheme: () => void;
}

export default function Login({ isDark, toggleTheme }: LoginProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => setIsLoading(false), 2000);
  };

  return (
    <>
      <AuthNavbar isDark={isDark} toggleTheme={toggleTheme} />
      <div className="container mx-auto px-4 py-8 pt-24">
        <div className="max-w-md mx-auto">
          <div className="relative">
            <div className={`absolute -inset-0.5 ${isDark ? 'bg-purple-600' : 'bg-purple-200'} rounded-3xl blur opacity-30`}></div>
            
            <div className={`relative ${isDark ? 'bg-[#1A1F2E]' : 'bg-white/70 backdrop-blur-sm'} rounded-3xl p-8 space-y-8 ${!isDark && 'shadow-xl'}`}>
              <div className="text-center space-y-2">
                <h2 className={`text-3xl font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>Bem-vindo de volta</h2>
                <p className={isDark ? 'text-purple-300' : 'text-purple-500'}>Conecte-se ao futuro do SDR com IA</p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-4">
                  <div className="relative">
                    <input
                      type="email"
                      placeholder="Seu email"
                      className={`peer w-full pl-4 pr-12 py-4 ${isDark ? 'bg-[#232838]' : 'bg-purple-50'} rounded-xl ${isDark ? 'text-white' : 'text-gray-900'} ${isDark ? 'placeholder-white/30' : 'placeholder-purple-300'} focus:outline-none focus:ring-2 ${isDark ? 'focus:ring-purple-500/30' : 'focus:ring-purple-500/50'} transition-all duration-300`}
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                    />
                    <Mail className={`absolute right-4 top-1/2 -translate-y-1/2 ${isDark ? 'text-purple-400' : 'text-purple-500'}`} size={20} />
                  </div>

                  <div className="relative">
                    <input
                      type="password"
                      placeholder="Sua senha"
                      className={`peer w-full pl-4 pr-12 py-4 ${isDark ? 'bg-[#232838]' : 'bg-purple-50'} rounded-xl ${isDark ? 'text-white' : 'text-gray-900'} ${isDark ? 'placeholder-white/30' : 'placeholder-purple-300'} focus:outline-none focus:ring-2 ${isDark ? 'focus:ring-purple-500/30' : 'focus:ring-purple-500/50'} transition-all duration-300`}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                    />
                    <Lock className={`absolute right-4 top-1/2 -translate-y-1/2 ${isDark ? 'text-purple-400' : 'text-purple-500'}`} size={20} />
                  </div>
                </div>

                <div className="flex justify-end">
                  <Link 
                    to="/forgot-password" 
                    className={`text-sm ${isDark ? 'text-purple-400 hover:text-purple-300' : 'text-purple-500 hover:text-purple-600'} transition-colors duration-300 hover:underline`}
                  >
                    Esqueceu a senha?
                  </Link>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="group relative w-full overflow-hidden bg-purple-500 rounded-xl p-4 transition-all duration-300 hover:bg-purple-600 active:scale-[0.98]"
                >
                  <div className="relative flex items-center justify-center gap-2">
                    <span className="text-white font-medium">
                      {isLoading ? 'Entrando...' : 'Entrar'}
                    </span>
                    <ArrowRight 
                      className={`w-5 h-5 text-white transition-all duration-300 ${
                        isLoading ? 'animate-spin' : 'group-hover:translate-x-1'
                      }`}
                    />
                  </div>
                </button>
              </form>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className={`w-full border-t ${isDark ? 'border-purple-500/20' : 'border-purple-200'}`}></div>
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className={`px-2 ${isDark ? 'bg-[#1A1F2E]' : 'bg-white'} ${isDark ? 'text-purple-300' : 'text-purple-500'}`}>ou continue com</span>
                </div>
              </div>

              <button className={`relative group w-full px-6 py-4 ${isDark ? 'bg-[#232838]' : 'bg-purple-50'} rounded-xl overflow-hidden transition-all duration-300 hover:scale-[1.02] active:scale-[0.98]`}>
                <div className="relative flex items-center justify-center gap-2">
                  <img src="https://www.google.com/favicon.ico" alt="Google" className="w-5 h-5" />
                  <span className={isDark ? 'text-purple-300' : 'text-purple-500'}>Google</span>
                </div>
              </button>

              <div className="text-center">
                <span className={isDark ? 'text-purple-300' : 'text-purple-500'}>Não tem uma conta? </span>
                <Link 
                  to="/register" 
                  className={`${isDark ? 'text-purple-400 hover:text-purple-300' : 'text-purple-500 hover:text-purple-600'} transition-colors duration-300 hover:underline`}
                >
                  Cadastre-se
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}