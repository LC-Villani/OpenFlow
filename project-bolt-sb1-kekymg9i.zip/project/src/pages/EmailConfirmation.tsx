import React from 'react';
import { Mail, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import AuthNavbar from '../components/AuthNavbar';

interface EmailConfirmationProps {
  isDark: boolean;
  toggleTheme: () => void;
}

export default function EmailConfirmation({ isDark, toggleTheme }: EmailConfirmationProps) {
  return (
    <>
      <AuthNavbar isDark={isDark} toggleTheme={toggleTheme} />
      <div className="container mx-auto px-4 py-8 pt-24">
        <div className="max-w-md mx-auto">
          <div className="relative">
            <div className={`absolute -inset-0.5 ${isDark ? 'bg-purple-600' : 'bg-purple-200'} rounded-3xl blur opacity-30`}></div>
            
            <div className={`relative ${isDark ? 'bg-[#1A1F2E]' : 'bg-white'} rounded-3xl p-8 space-y-8 ${!isDark && 'shadow-xl'}`}>
              <div className="text-center space-y-6">
                <div className={`w-20 h-20 mx-auto ${isDark ? 'bg-purple-500/20' : 'bg-purple-100'} rounded-full flex items-center justify-center`}>
                  <Mail size={40} className={isDark ? 'text-purple-400' : 'text-purple-500'} />
                </div>
                
                <div className="space-y-2">
                  <h2 className={`text-3xl font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>Quase lá!</h2>
                  <p className={isDark ? 'text-purple-300' : 'text-purple-500'}>
                    Verifique sua caixa de entrada para ativar sua conta OpenFlow
                  </p>
                </div>

                <div className="space-y-4">
                  <button className="group relative w-full overflow-hidden bg-purple-500 rounded-xl p-4 transition-all duration-300 hover:bg-purple-600 active:scale-[0.98]">
                    <div className="relative flex items-center justify-center gap-2">
                      <span className="text-white font-medium">
                        Reenviar email de confirmação
                      </span>
                    </div>
                  </button>
                  
                  <Link
                    to="/login"
                    className={`inline-flex items-center justify-center w-full ${isDark ? 'text-purple-400 hover:text-purple-300' : 'text-purple-500 hover:text-purple-600'} transition-colors duration-300 group`}
                  >
                    <span>Voltar ao login</span>
                    <ArrowRight size={20} className="ml-2 group-hover:translate-x-1 transition-transform duration-300" />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}