import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Mail, Lock, User, Phone, Building2, ArrowRight } from 'lucide-react';
import AuthNavbar from '../components/AuthNavbar';

interface RegisterProps {
  isDark: boolean;
  toggleTheme: () => void;
}

type AccountType = 'personal' | 'business' | null;

export default function Register({ isDark, toggleTheme }: RegisterProps) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [accountType, setAccountType] = useState<AccountType>(null);
  const [isLoading, setIsLoading] = useState(false);
  
  const getPasswordStrength = (pass: string) => {
    if (!pass) return 0;
    let strength = 0;
    if (pass.length >= 8) strength++;
    if (/[A-Z]/.test(pass)) strength++;
    if (/[0-9]/.test(pass)) strength++;
    if (/[^A-Za-z0-9]/.test(pass)) strength++;
    return strength;
  };

  const passwordStrength = getPasswordStrength(password);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => setIsLoading(false), 2000);
  };

  return (
    <>
      <AuthNavbar isDark={isDark} toggleTheme={toggleTheme} />
      <div className="container mx-auto px-4 py-8 pt-24">
        <div className="max-w-md mx-auto">
          <div className="relative">
            <div className={`absolute -inset-0.5 ${isDark ? 'bg-purple-600' : 'bg-purple-200'} rounded-3xl blur opacity-30`}></div>
            
            <div className={`relative ${isDark ? 'bg-[#1A1F2E]' : 'bg-white/70 backdrop-blur-sm'} rounded-3xl p-8 space-y-8 ${!isDark && 'shadow-xl'}`}>
              <div className="text-center space-y-2">
                <h2 className={`text-3xl font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>Crie sua conta</h2>
                <p className={isDark ? 'text-purple-300' : 'text-purple-500'}>Comece sua jornada com OpenFlow</p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-4">
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="Seu nome completo"
                      className={`peer w-full pl-4 pr-12 py-4 ${isDark ? 'bg-[#232838]' : 'bg-purple-50'} rounded-xl ${isDark ? 'text-white' : 'text-gray-900'} ${isDark ? 'placeholder-white/30' : 'placeholder-purple-300'} focus:outline-none focus:ring-2 ${isDark ? 'focus:ring-purple-500/30' : 'focus:ring-purple-500/50'} transition-all duration-300`}
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                    />
                    <User className={`absolute right-4 top-1/2 -translate-y-1/2 ${isDark ? 'text-purple-400' : 'text-purple-500'}`} size={20} />
                  </div>

                  <div className="relative">
                    <input
                      type="email"
                      placeholder="Seu email"
                      className={`peer w-full pl-4 pr-12 py-4 ${isDark ? 'bg-[#232838]' : 'bg-purple-50'} rounded-xl ${isDark ? 'text-white' : 'text-gray-900'} ${isDark ? 'placeholder-white/30' : 'placeholder-purple-300'} focus:outline-none focus:ring-2 ${isDark ? 'focus:ring-purple-500/30' : 'focus:ring-purple-500/50'} transition-all duration-300`}
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                    />
                    <Mail className={`absolute right-4 top-1/2 -translate-y-1/2 ${isDark ? 'text-purple-400' : 'text-purple-500'}`} size={20} />
                  </div>

                  <div className="relative">
                    <input
                      type="tel"
                      placeholder="Seu telefone"
                      className={`peer w-full pl-4 pr-12 py-4 ${isDark ? 'bg-[#232838]' : 'bg-purple-50'} rounded-xl ${isDark ? 'text-white' : 'text-gray-900'} ${isDark ? 'placeholder-white/30' : 'placeholder-purple-300'} focus:outline-none focus:ring-2 ${isDark ? 'focus:ring-purple-500/30' : 'focus:ring-purple-500/50'} transition-all duration-300`}
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                    />
                    <Phone className={`absolute right-4 top-1/2 -translate-y-1/2 ${isDark ? 'text-purple-400' : 'text-purple-500'}`} size={20} />
                  </div>

                  <div className="space-y-2">
                    <div className="relative">
                      <input
                        type="password"
                        placeholder="Crie uma senha"
                        className={`peer w-full pl-4 pr-12 py-4 ${isDark ? 'bg-[#232838]' : 'bg-purple-50'} rounded-xl ${isDark ? 'text-white' : 'text-gray-900'} ${isDark ? 'placeholder-white/30' : 'placeholder-purple-300'} focus:outline-none focus:ring-2 ${isDark ? 'focus:ring-purple-500/30' : 'focus:ring-purple-500/50'} transition-all duration-300`}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                      />
                      <Lock className={`absolute right-4 top-1/2 -translate-y-1/2 ${isDark ? 'text-purple-400' : 'text-purple-500'}`} size={20} />
                    </div>
                    
                    <div className="flex gap-2">
                      {[...Array(4)].map((_, i) => (
                        <div
                          key={i}
                          className={`h-1 flex-1 rounded-full transition-colors duration-300 ${
                            i < passwordStrength
                              ? [
                                  'bg-red-500',
                                  'bg-orange-500',
                                  'bg-yellow-500',
                                  'bg-green-500',
                                ][passwordStrength - 1]
                              : isDark ? 'bg-purple-500/20' : 'bg-purple-100'
                          }`}
                        />
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className={`block text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
                      Tipo de conta
                    </label>
                    <div className="grid grid-cols-2 gap-4">
                      <button
                        type="button"
                        onClick={() => setAccountType('personal')}
                        className={`p-4 rounded-xl border-2 transition-all duration-300 flex flex-col items-center gap-2 ${
                          accountType === 'personal'
                            ? isDark
                              ? 'bg-purple-500/20 border-purple-500'
                              : 'bg-purple-50 border-purple-500'
                            : isDark
                            ? 'bg-[#232838] border-purple-500/20 hover:border-purple-500/40'
                            : 'bg-purple-50/50 border-purple-200 hover:border-purple-300'
                        }`}
                      >
                        <User className={accountType === 'personal' ? 'text-purple-500' : isDark ? 'text-purple-400' : 'text-purple-500'} />
                        <span className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>Uso Pessoal</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setAccountType('business')}
                        className={`p-4 rounded-xl border-2 transition-all duration-300 flex flex-col items-center gap-2 ${
                          accountType === 'business'
                            ? isDark
                              ? 'bg-purple-500/20 border-purple-500'
                              : 'bg-purple-50 border-purple-500'
                            : isDark
                            ? 'bg-[#232838] border-purple-500/20 hover:border-purple-500/40'
                            : 'bg-purple-50/50 border-purple-200 hover:border-purple-300'
                        }`}
                      >
                        <Building2 className={accountType === 'business' ? 'text-purple-500' : isDark ? 'text-purple-400' : 'text-purple-500'} />
                        <span className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>Para Empresa</span>
                      </button>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="terms"
                    className={`rounded ${isDark ? 'bg-[#232838] border-purple-500/30' : 'bg-purple-50 border-purple-200'} text-purple-500 focus:ring-purple-500/50`}
                  />
                  <label htmlFor="terms" className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-500'}`}>
                    Eu aceito os{' '}
                    <Link to="/terms" className={`${isDark ? 'text-purple-400 hover:text-purple-300' : 'text-purple-500 hover:text-purple-600'} hover:underline`}>
                      Termos de Serviço
                    </Link>
                  </label>
                </div>

                <button
                  type="submit"
                  disabled={isLoading || !accountType}
                  className="group relative w-full overflow-hidden bg-purple-500 rounded-xl p-4 transition-all duration-300 hover:bg-purple-600 active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <div className="relative flex items-center justify-center gap-2">
                    <span className="text-white font-medium">
                      {isLoading ? 'Criando conta...' : 'Criar conta'}
                    </span>
                    <ArrowRight 
                      className={`w-5 h-5 text-white transition-all duration-300 ${
                        isLoading ? 'animate-spin' : 'group-hover:translate-x-1'
                      }`}
                    />
                  </div>
                </button>
              </form>

              <div className="text-center">
                <span className={isDark ? 'text-purple-300' : 'text-purple-500'}>Já tem uma conta? </span>
                <Link 
                  to="/login" 
                  className={`${isDark ? 'text-purple-400 hover:text-purple-300' : 'text-purple-500 hover:text-purple-600'} transition-colors duration-300 hover:underline`}
                >
                  Faça login
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}