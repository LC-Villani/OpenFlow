import React, { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, ArrowRight } from 'lucide-react';
import AuthNavbar from '../components/AuthNavbar';

interface VerificationCodeProps {
  isDark: boolean;
  toggleTheme: () => void;
}

export default function VerificationCode({ isDark, toggleTheme }: VerificationCodeProps) {
  const [code, setCode] = useState(['', '', '', '', '', '']);
  const [isLoading, setIsLoading] = useState(false);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    inputRefs.current[0]?.focus();
  }, []);

  const handleChange = (index: number, value: string) => {
    if (value.length <= 1 && /^[0-9]*$/.test(value)) {
      const newCode = [...code];
      newCode[index] = value;
      setCode(newCode);
      
      if (value && index < 5) {
        inputRefs.current[index + 1]?.focus();
      }
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !code[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => setIsLoading(false), 2000);
  };

  return (
    <>
      <AuthNavbar isDark={isDark} toggleTheme={toggleTheme} />
      <div className="container mx-auto px-4 py-8 pt-24">
        <div className="max-w-md mx-auto">
          <div className="relative">
            <div className={`absolute -inset-0.5 ${isDark ? 'bg-purple-600' : 'bg-purple-200'} rounded-3xl blur opacity-30`}></div>
            
            <div className={`relative ${isDark ? 'bg-[#1A1F2E]' : 'bg-white/70 backdrop-blur-sm'} rounded-3xl p-8 space-y-8 ${!isDark && 'shadow-xl'}`}>
              <Link to="/forgot-password" className={`inline-flex items-center ${isDark ? 'text-purple-400 hover:text-purple-300' : 'text-purple-500 hover:text-purple-600'} transition-colors duration-300`}>
                <ArrowLeft size={20} className="mr-2" />
                Voltar
              </Link>

              <div className="text-center space-y-2">
                <h2 className={`text-3xl font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>Código de verificação</h2>
                <p className={isDark ? 'text-purple-300' : 'text-purple-500'}>
                  Digite o código de 6 dígitos enviado para seu email
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="flex justify-center gap-2">
                  {code.map((digit, index) => (
                    <input
                      key={index}
                      ref={el => inputRefs.current[index] = el}
                      type="text"
                      maxLength={1}
                      value={digit}
                      onChange={e => handleChange(index, e.target.value)}
                      onKeyDown={e => handleKeyDown(index, e)}
                      className={`w-12 h-14 text-center text-xl font-semibold ${
                        isDark ? 'bg-[#232838] text-white' : 'bg-purple-50 text-gray-900'
                      } rounded-xl ${isDark ? 'placeholder-white/30' : 'placeholder-purple-300'} focus:outline-none focus:ring-2 ${
                        isDark ? 'focus:ring-purple-500/30' : 'focus:ring-purple-500/50'
                      } transition-all duration-300`}
                    />
                  ))}
                </div>

                <button
                  type="submit"
                  disabled={code.some(digit => !digit) || isLoading}
                  className="group relative w-full overflow-hidden bg-purple-500 rounded-xl p-4 transition-all duration-300 hover:bg-purple-600 active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <div className="relative flex items-center justify-center gap-2">
                    <span className="text-white font-medium">
                      {isLoading ? 'Verificando...' : 'Verificar código'}
                    </span>
                    <ArrowRight 
                      className={`w-5 h-5 text-white transition-all duration-300 ${
                        isLoading ? 'animate-spin' : 'group-hover:translate-x-1'
                      }`}
                    />
                  </div>
                </button>

                <div className="text-center">
                  <button
                    type="button"
                    className={`${isDark ? 'text-purple-400 hover:text-purple-300' : 'text-purple-500 hover:text-purple-600'} transition-colors duration-300 hover:underline`}
                  >
                    Reenviar código
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}