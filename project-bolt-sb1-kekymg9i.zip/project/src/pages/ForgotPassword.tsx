import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Mail, ArrowLeft, ArrowRight } from 'lucide-react';
import AuthNavbar from '../components/AuthNavbar';

interface ForgotPasswordProps {
  isDark: boolean;
  toggleTheme: () => void;
}

export default function ForgotPassword({ isDark, toggleTheme }: ForgotPasswordProps) {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      setSent(true);
    }, 2000);
  };

  return (
    <>
      <AuthNavbar isDark={isDark} toggleTheme={toggleTheme} />
      <div className="container mx-auto px-4 py-8 pt-24">
        <div className="max-w-md mx-auto">
          <div className="relative">
            <div className={`absolute -inset-0.5 ${isDark ? 'bg-purple-600' : 'bg-purple-200'} rounded-3xl blur opacity-30`}></div>
            
            <div className={`relative ${isDark ? 'bg-[#1A1F2E]' : 'bg-white'} rounded-3xl p-8 space-y-8 ${!isDark && 'shadow-xl'}`}>
              <Link to="/login" className={`inline-flex items-center ${isDark ? 'text-purple-400 hover:text-purple-300' : 'text-purple-500 hover:text-purple-600'} transition-colors duration-300`}>
                <ArrowLeft size={20} className="mr-2" />
                Voltar ao login
              </Link>

              {!sent ? (
                <>
                  <div className="text-center space-y-2">
                    <h2 className={`text-3xl font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>Esqueceu sua senha?</h2>
                    <p className={isDark ? 'text-purple-300' : 'text-purple-500'}>
                      Digite seu email para receber instruções de recuperação
                    </p>
                  </div>

                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="relative">
                      <input
                        type="email"
                        placeholder="Seu email"
                        className={`w-full pl-4 pr-12 py-4 ${isDark ? 'bg-[#232838]' : 'bg-white'} rounded-xl ${isDark ? 'text-white' : 'text-gray-900'} border ${isDark ? 'border-purple-500/20' : 'border-purple-100'} focus:outline-none focus:ring-2 ${isDark ? 'focus:ring-purple-500/30' : 'focus:ring-purple-500/50'} transition-all duration-300`}
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                      />
                      <Mail className={`absolute right-4 top-1/2 -translate-y-1/2 ${isDark ? 'text-purple-400' : 'text-purple-500'}`} size={20} />
                    </div>

                    <button
                      type="submit"
                      disabled={isLoading}
                      className="group relative w-full overflow-hidden bg-purple-500 rounded-xl p-4 transition-all duration-300 hover:bg-purple-600 active:scale-[0.98]"
                    >
                      <div className="relative flex items-center justify-center gap-2">
                        <span className="text-white font-medium">
                          {isLoading ? 'Enviando...' : 'Enviar instruções'}
                        </span>
                        <ArrowRight 
                          className={`w-5 h-5 text-white transition-all duration-300 ${
                            isLoading ? 'animate-spin' : 'group-hover:translate-x-1'
                          }`}
                        />
                      </div>
                    </button>
                  </form>
                </>
              ) : (
                <div className="text-center space-y-6">
                  <div className={`w-16 h-16 mx-auto ${isDark ? 'bg-purple-500/20' : 'bg-purple-100'} rounded-full flex items-center justify-center`}>
                    <Mail size={32} className={isDark ? 'text-purple-400' : 'text-purple-500'} />
                  </div>
                  <div className="space-y-2">
                    <h2 className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>Verifique seu email</h2>
                    <p className={isDark ? 'text-purple-300' : 'text-purple-500'}>
                      Enviamos as instruções de recuperação para seu email
                    </p>
                  </div>
                  <button
                    onClick={() => setSent(false)}
                    className={`${isDark ? 'text-purple-400 hover:text-purple-300' : 'text-purple-500 hover:text-purple-600'} transition-colors duration-300 hover:underline`}
                  >
                    Não recebeu? Enviar novamente
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}