import React from 'react';
import { Link } from 'react-router-dom';
import { MoveLeft, Search } from 'lucide-react';

interface Error404Props {
  isDark: boolean;
}

export default function Error404({ isDark }: Error404Props) {
  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="text-center">
        <div className="relative mb-8">
          <div className={`text-[150px] md:text-[200px] font-bold ${isDark ? 'text-white/5' : 'text-purple-100'} select-none`}>
            404
          </div>
          <div className="absolute inset-0 flex items-center justify-center">
            <Search className={`w-24 h-24 ${isDark ? 'text-purple-400' : 'text-purple-500'} animate-pulse`} />
          </div>
        </div>

        <h1 className={`text-3xl md:text-4xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
          Página não encontrada
        </h1>
        
        <p className={`text-lg mb-8 max-w-md mx-auto ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
          Ops! Parece que você se perdeu. A página que você está procurando não existe ou foi movida.
        </p>

        <Link
          to="/home"
          className="inline-flex items-center gap-2 px-6 py-3 bg-purple-500 text-white rounded-xl hover:bg-purple-600 transition-all duration-300 group"
        >
          <MoveLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform duration-300" />
          <span>Voltar ao início</span>
        </Link>
      </div>
    </div>
  );
}