import React from 'react';
import { Link } from 'react-router-dom';
import { MoveLeft, ShieldBan } from 'lucide-react';

interface Error403Props {
  isDark: boolean;
}

export default function Error403({ isDark }: Error403Props) {
  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="text-center">
        <div className="relative mb-8">
          <div className={`text-[150px] md:text-[200px] font-bold ${isDark ? 'text-white/5' : 'text-purple-100'} select-none`}>
            403
          </div>
          <div className="absolute inset-0 flex items-center justify-center">
            <ShieldBan className={`w-24 h-24 ${isDark ? 'text-purple-400' : 'text-purple-500'} animate-pulse`} />
          </div>
        </div>

        <h1 className={`text-3xl md:text-4xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
          Acesso negado
        </h1>
        
        <p className={`text-lg mb-8 max-w-md mx-auto ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
          Desculpe, mas você não tem permissão para acessar esta página. Se você acha que isso é um erro, entre em contato com o suporte.
        </p>

        <div className="flex flex-col md:flex-row items-center justify-center gap-4">
          <Link
            to="/home"
            className="inline-flex items-center gap-2 px-6 py-3 bg-purple-500 text-white rounded-xl hover:bg-purple-600 transition-all duration-300 group"
          >
            <MoveLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform duration-300" />
            <span>Voltar ao início</span>
          </Link>

          <Link
            to="/help"
            className={`inline-flex items-center gap-2 px-6 py-3 ${
              isDark ? 'bg-[#232838] text-purple-300 hover:bg-[#2A303F]' : 'bg-purple-50 text-purple-600 hover:bg-purple-100'
            } rounded-xl transition-all duration-300`}
          >
            <span>Contatar suporte</span>
          </Link>
        </div>
      </div>
    </div>
  );
}