import React, { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { CreditCard, ArrowLeft, Calendar, Lock, Receipt, Ban as Bank, CheckCircle2 } from 'lucide-react';

interface PaymentProps {
  isDark: boolean;
}

type PaymentMethod = 'credit' | 'debit' | 'boleto';

const agents = {
  delivery: {
    title: 'Agente para Delivery',
    price: 199,
    image: 'https://images.unsplash.com/photo-1526367790999-0150786686a2?auto=format&fit=crop&q=80&w=500'
  },
  ecommerce: {
    title: 'Agente para E-commerce',
    price: 249,
    image: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&q=80&w=500'
  },
  hotel: {
    title: 'Agente para Hotelaria',
    price: 299,
    image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&q=80&w=500'
  },
  health: {
    title: 'Agente para Saúde',
    price: 349,
    image: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&q=80&w=500'
  },
  clinic: {
    title: 'Agente para Consultório',
    price: 179,
    image: 'https://images.unsplash.com/photo-1516549655169-df83a0774514?auto=format&fit=crop&q=80&w=500'
  }
};

export default function Payment({ isDark }: PaymentProps) {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('credit');
  const [cardNumber, setCardNumber] = useState('');
  const [cardName, setCardName] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvv, setCvv] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const agent = id ? agents[id as keyof typeof agents] : agents.ecommerce;

  const formatCardNumber = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    return numbers.replace(/(\d{4})/g, '$1 ').trim().slice(0, 19);
  };

  const formatExpiryDate = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length >= 2) {
      return `${numbers.slice(0, 2)}/${numbers.slice(2, 4)}`;
    }
    return numbers;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      navigate('/payment-success');
    }, 2000);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className={`max-w-4xl w-full ${isDark ? 'bg-[#1A1F2E]' : 'bg-white'} rounded-2xl overflow-hidden`}>
        <div className="flex flex-col lg:flex-row">
          {/* Coluna da Esquerda - Detalhes do Produto */}
          <div className={`lg:w-1/3 ${isDark ? 'bg-[#232838]' : 'bg-purple-50'} p-8`}>
            <Link
              to={`/agent/${id}`}
              className={`inline-flex items-center ${isDark ? 'text-purple-400 hover:text-purple-300' : 'text-purple-500 hover:text-purple-600'} transition-colors duration-300 mb-8`}
            >
              <ArrowLeft size={20} className="mr-2" />
              Voltar
            </Link>

            <div className="relative h-48 rounded-xl overflow-hidden mb-6">
              <img
                src={agent.image}
                alt={agent.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
              <div className="absolute bottom-4 left-4 right-4">
                <h2 className="text-2xl font-bold text-white mb-2">
                  {agent.title}
                </h2>
                <div className="flex items-center justify-between">
                  <span className="text-white/80">Valor mensal</span>
                  <span className="text-white font-bold">R$ {agent.price},00</span>
                </div>
              </div>
            </div>

            <div className={`p-4 rounded-xl ${isDark ? 'bg-[#1A1F2E]' : 'bg-white'} mb-6`}>
              <div className="flex items-center justify-between mb-2">
                <span className={isDark ? 'text-purple-300' : 'text-purple-600'}>Subtotal</span>
                <span className={`font-medium ${isDark ? 'text-white' : 'text-gray-900'}`}>R$ {agent.price},00</span>
              </div>
              <div className="flex items-center justify-between">
                <span className={isDark ? 'text-purple-300' : 'text-purple-600'}>Taxa</span>
                <span className={`font-medium ${isDark ? 'text-white' : 'text-gray-900'}`}>R$ 0,00</span>
              </div>
              <div className="h-px bg-purple-500/20 my-4" />
              <div className="flex items-center justify-between">
                <span className={`font-medium ${isDark ? 'text-white' : 'text-gray-900'}`}>Total</span>
                <span className="text-xl font-bold text-purple-500">R$ {agent.price},00</span>
              </div>
            </div>

            <div className={`p-4 rounded-xl ${isDark ? 'bg-[#1A1F2E]' : 'bg-white'}`}>
              <div className="flex items-center gap-3 mb-4">
                <Lock className={`w-5 h-5 ${isDark ? 'text-purple-400' : 'text-purple-500'}`} />
                <span className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
                  Pagamento 100% seguro
                </span>
              </div>
              <p className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
                Seus dados são criptografados e processados com segurança.
              </p>
            </div>
          </div>

          {/* Coluna da Direita - Formulário de Pagamento */}
          <div className="lg:w-2/3 p-8">
            <h2 className={`text-2xl font-bold mb-6 ${isDark ? 'text-white' : 'text-gray-900'}`}>
              Forma de Pagamento
            </h2>

            {/* Tabs de Métodos de Pagamento */}
            <div className="flex gap-4 mb-8">
              <button
                onClick={() => setPaymentMethod('credit')}
                className={`flex-1 p-4 rounded-xl border-2 transition-all duration-300 flex flex-col items-center gap-2 ${
                  paymentMethod === 'credit'
                    ? isDark
                      ? 'bg-purple-500/20 border-purple-500'
                      : 'bg-purple-50 border-purple-500'
                    : isDark
                    ? 'bg-[#232838] border-purple-500/20'
                    : 'bg-purple-50/50 border-purple-200'
                }`}
              >
                <CreditCard className={paymentMethod === 'credit' ? 'text-purple-500' : isDark ? 'text-purple-400' : 'text-purple-500'} />
                <span className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>Crédito</span>
              </button>

              <button
                onClick={() => setPaymentMethod('debit')}
                className={`flex-1 p-4 rounded-xl border-2 transition-all duration-300 flex flex-col items-center gap-2 ${
                  paymentMethod === 'debit'
                    ? isDark
                      ? 'bg-purple-500/20 border-purple-500'
                      : 'bg-purple-50 border-purple-500'
                    : isDark
                    ? 'bg-[#232838] border-purple-500/20'
                    : 'bg-purple-50/50 border-purple-200'
                }`}
              >
                <Bank className={paymentMethod === 'debit' ? 'text-purple-500' : isDark ? 'text-purple-400' : 'text-purple-500'} />
                <span className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>Débito</span>
              </button>

              <button
                onClick={() => setPaymentMethod('boleto')}
                className={`flex-1 p-4 rounded-xl border-2 transition-all duration-300 flex flex-col items-center gap-2 ${
                  paymentMethod === 'boleto'
                    ? isDark
                      ? 'bg-purple-500/20 border-purple-500'
                      : 'bg-purple-50 border-purple-500'
                    : isDark
                    ? 'bg-[#232838] border-purple-500/20'
                    : 'bg-purple-50/50 border-purple-200'
                }`}
              >
                <Receipt className={paymentMethod === 'boleto' ? 'text-purple-500' : isDark ? 'text-purple-400' : 'text-purple-500'} />
                <span className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>Boleto</span>
              </button>
            </div>

            {/* Formulário de Cartão */}
            {(paymentMethod === 'credit' || paymentMethod === 'debit') && (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <label className={`block text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
                    Número do Cartão
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      value={cardNumber}
                      onChange={(e) => setCardNumber(formatCardNumber(e.target.value))}
                      placeholder="0000 0000 0000 0000"
                      className={`w-full pl-4 pr-12 py-4 ${isDark ? 'bg-[#232838]' : 'bg-purple-50'} rounded-xl ${isDark ? 'text-white' : 'text-gray-900'} focus:outline-none focus:ring-2 ${isDark ? 'focus:ring-purple-500/30' : 'focus:ring-purple-500/50'} transition-all duration-300`}
                    />
                    <CreditCard className={`absolute right-4 top-1/2 -translate-y-1/2 ${isDark ? 'text-purple-400' : 'text-purple-500'}`} />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className={`block text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
                    Nome no Cartão
                  </label>
                  <input
                    type="text"
                    value={cardName}
                    onChange={(e) => setCardName(e.target.value)}
                    placeholder="Nome impresso no cartão"
                    className={`w-full px-4 py-4 ${isDark ? 'bg-[#232838]' : 'bg-purple-50'} rounded-xl ${isDark ? 'text-white' : 'text-gray-900'} focus:outline-none focus:ring-2 ${isDark ? 'focus:ring-purple-500/30' : 'focus:ring-purple-500/50'} transition-all duration-300`}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className={`block text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
                      Validade
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        value={expiryDate}
                        onChange={(e) => setExpiryDate(formatExpiryDate(e.target.value))}
                        placeholder="MM/AA"
                        className={`w-full pl-4 pr-12 py-4 ${isDark ? 'bg-[#232838]' : 'bg-purple-50'} rounded-xl ${isDark ? 'text-white' : 'text-gray-900'} focus:outline-none focus:ring-2 ${isDark ? 'focus:ring-purple-500/30' : 'focus:ring-purple-500/50'} transition-all duration-300`}
                      />
                      <Calendar className={`absolute right-4 top-1/2 -translate-y-1/2 ${isDark ? 'text-purple-400' : 'text-purple-500'}`} />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className={`block text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
                      CVV
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        value={cvv}
                        onChange={(e) => setCvv(e.target.value.replace(/\D/g, '').slice(0, 3))}
                        placeholder="000"
                        className={`w-full pl-4 pr-12 py-4 ${isDark ? 'bg-[#232838]' : 'bg-purple-50'} rounded-xl ${isDark ? 'text-white' : 'text-gray-900'} focus:outline-none focus:ring-2 ${isDark ? 'focus:ring-purple-500/30' : 'focus:ring-purple-500/50'} transition-all duration-300`}
                      />
                      <Lock className={`absolute right-4 top-1/2 -translate-y-1/2 ${isDark ? 'text-purple-400' : 'text-purple-500'}`} />
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isLoading || !cardNumber || !cardName || !expiryDate || !cvv}
                  className="w-full py-4 bg-purple-500 text-white rounded-xl hover:bg-purple-600 transition-all duration-300 flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isLoading ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      <span>Processando...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-5 h-5" />
                      <span>Finalizar Pagamento</span>
                    </>
                  )}
                </button>
              </form>
            )}

            {/* Boleto */}
            {paymentMethod === 'boleto' && (
              <div className="space-y-6">
                <div className={`p-6 rounded-xl ${isDark ? 'bg-[#232838]' : 'bg-purple-50'}`}>
                  <div className="flex items-center gap-3 mb-4">
                    <Receipt className={isDark ? 'text-purple-400' : 'text-purple-500'} />
                    <h3 className={`font-medium ${isDark ? 'text-white' : 'text-gray-900'}`}>
                      Pagamento via Boleto
                    </h3>
                  </div>
                  <p className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'} mb-4`}>
                    Ao gerar o boleto, você terá até 3 dias úteis para efetuar o pagamento. O acesso ao agente será liberado assim que o pagamento for confirmado.
                  </p>
                  <div className={`p-4 rounded-lg ${isDark ? 'bg-[#1A1F2E]' : 'bg-white'}`}>
                    <div className="flex items-center justify-between mb-2">
                      <span className={isDark ? 'text-purple-300' : 'text-purple-600'}>Valor do Boleto</span>
                      <span className={`font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>R$ {agent.price},00</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className={isDark ? 'text-purple-300' : 'text-purple-600'}>Vencimento</span>
                      <span className={`font-medium ${isDark ? 'text-white' : 'text-gray-900'}`}>3 dias úteis</span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={handleSubmit}
                  disabled={isLoading}
                  className="w-full py-4 bg-purple-500 text-white rounded-xl hover:bg-purple-600 transition-all duration-300 flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isLoading ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      <span>Gerando boleto...</span>
                    </>
                  ) : (
                    <>
                      <Receipt className="w-5 h-5" />
                      <span>Gerar Boleto</span>
                    </>
                  )}
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}