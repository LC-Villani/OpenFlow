import React from 'react';
import { Link } from 'react-router-dom';
import { X } from 'lucide-react';

interface TermsProps {
  isDark: boolean;
}

export default function Terms({ isDark }: TermsProps) {
  const currentDate = new Date().toLocaleDateString('pt-BR');

  const footerSections = [
    {
      title: 'Produtos',
      links: [
        { label: 'Assistente IA', href: '/products/ai-assistant' },
        { label: 'Qualificação de Leads', href: '/products/lead-qualification' },
        { label: 'Dashboard Analítico', href: '/products/analytics' },
        { label: 'Colaboração em Equipe', href: '/products/team' },
      ],
    },
    {
      title: 'Empresa',
      links: [
        { label: 'Sobre Nós', href: '/about' },
        { label: 'Carreiras', href: '/careers' },
        { label: 'Blog', href: '/blog' },
        { label: 'Contato', href: '/contact' },
      ],
    },
    {
      title: 'Legal',
      links: [
        { label: 'Política de Privacidade', href: '/privacy' },
        { label: 'Termos de Serviço', href: '/terms' },
        { label: 'Política de Cookies', href: '/cookies' },
      ],
    },
  ];

  return (
    <div className={`min-h-screen ${isDark ? 'bg-[#0B1121] bg-grid-pattern' : 'bg-[#f8f8f8] bg-grid-pattern-light'}`}>
      {/* Logo */}
      <div className="container mx-auto px-4 py-8">
        <Link to="/" className="flex items-center gap-3 group">
          <div className="relative">
            <div className={`w-10 h-10 ${isDark ? 'bg-[#6D28D9]' : 'bg-purple-500'} rounded-xl flex items-center justify-center overflow-hidden`}>
              <X className="w-6 h-6 text-white relative z-10 group-hover:rotate-180 transition-transform duration-700" />
            </div>
          </div>
          <div className="flex items-center">
            <span className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>Open</span>
            <span className={`text-2xl font-bold ${isDark ? 'text-[#7C3AED]' : 'text-purple-500'}`}>Flow</span>
          </div>
        </Link>
      </div>

      {/* Conteúdo */}
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className={`${isDark ? 'text-white' : 'text-gray-900'} space-y-8`}>
          <div className="text-center mb-12">
            <h1 className="text-3xl font-bold mb-2">Termos e Condições de Uso do Software</h1>
            <p className={`${isDark ? 'text-purple-300' : 'text-purple-600'}`}>Última atualização: {currentDate}</p>
          </div>

          <div className={`space-y-8 ${isDark ? 'text-purple-300' : 'text-purple-900'}`}>
            <p>
              Estes Termos e Condições de Uso ("Termos") regem o acesso e uso do software Jarvis ("Software"), 
              disponibilizado pela empresa OpenFlow, pessoa jurídica de direito privado, inscrita no CNPJ sob o 
              nº [CNPJ da empresa], doravante denominada OPENFLOW. Ao acessar ou utilizar o Software, o USUÁRIO 
              concorda com estes Termos. Caso o USUÁRIO não concorde com as condições aqui descritas, deverá 
              cessar imediatamente o uso do Software.
            </p>

            <section>
              <h2 className={`text-xl font-semibold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
                Artigo 1 – Definições
              </h2>
              <div className="space-y-2">
                <p>1.1. OPENFLOW: Empresa proprietária e fornecedora do Software.</p>
                <p>1.2. Software: Plataforma digital denominada Jarvis, que oferece serviços de atendimento com inteligência artificial, disponível para qualquer pessoa que aceite os Termos de Uso.</p>
                <p>1.3. USUÁRIO: Qualquer pessoa, física ou jurídica, que utilize o Software, estando ciente e de acordo com os Termos estabelecidos.</p>
              </div>
            </section>

            <section>
              <h2 className={`text-xl font-semibold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
                Artigo 2 – Objeto
              </h2>
              <div className="space-y-2">
                <p>2.1. Estes Termos regulam o uso do Software, incluindo todas as suas funcionalidades, obrigações das partes, políticas de pagamento e coleta de dados.</p>
                <p>2.2. O Software está disponível para qualquer pessoa que aceite estes Termos, sem restrições quanto ao tipo de usuário, desde que o uso esteja em conformidade com a legislação vigente.</p>
                <p>2.3. O uso do Software para atividades ilícitas, fraudulentas, ou prejudiciais é estritamente proibido.</p>
              </div>
            </section>

            <section>
              <h2 className={`text-xl font-semibold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
                Artigo 3 – Acesso e Cadastro
              </h2>
              <div className="space-y-2">
                <p>3.1. O uso do Software não requer a criação de conta empresarial ou o fornecimento de CNPJ. O cadastro deve ser realizado por qualquer pessoa que aceite os Termos, fornecendo informações precisas e verdadeiras.</p>
                <p>3.2. O USUÁRIO é responsável por proteger suas credenciais de acesso (login e senha) e por todas as atividades realizadas em sua conta.</p>
                <p>3.3. Em caso de uso indevido ou não autorizado do Software, o USUÁRIO deve notificar a OPENFLOW imediatamente.</p>
              </div>
            </section>

            <section>
              <h2 className={`text-xl font-semibold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
                Artigo 4 – Uso do Software
              </h2>
              <div className="space-y-2">
                <p>4.1. O Software é disponibilizado para uso pessoal e/ou profissional, desde que o uso seja legal e em conformidade com os Termos de Uso.</p>
                <p>4.2. É proibido o uso do Software para:</p>
                <ul className="list-disc pl-6 space-y-1">
                  <li>Ações fraudulentas, ilegais ou nocivas a terceiros;</li>
                  <li>Realização de golpes, fraudes ou qualquer outra atividade ilícita;</li>
                  <li>Qualquer outro uso que infrinja os direitos de propriedade intelectual ou que seja contrário à boa-fé e à ordem pública.</li>
                </ul>
                <p>4.3. O USUÁRIO compromete-se a utilizar o Software exclusivamente para fins lícitos e legais.</p>
              </div>
            </section>

            <section>
              <h2 className={`text-xl font-semibold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
                Artigo 5 – Planos, Pagamentos e Cancelamento
              </h2>
              <div className="space-y-2">
                <p>5.1. O Software oferece diferentes planos, conforme descrito no momento da contratação.</p>
                <p>5.2. O pagamento do plano será realizado por meio das plataformas indicadas pela OPENFLOW, com emissão de recibos ou comprovantes conforme a transação.</p>
                <p>5.3. Política de Cancelamento:</p>
                <ul className="list-disc pl-6 space-y-1">
                  <li>O USUÁRIO pode cancelar a assinatura a qualquer momento, sem a necessidade de justificativa.</li>
                  <li>Os valores pagos não são reembolsáveis, salvo em circunstâncias excepcionais previstas por lei.</li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className={`text-xl font-semibold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
                Artigo 6 – Obrigações e Responsabilidades do Usuário
              </h2>
              <div className="space-y-2">
                <p>6.1. O USUÁRIO compromete-se a utilizar o Software de maneira responsável, legal e ética.</p>
                <p>6.2. É responsabilidade do USUÁRIO:</p>
                <ul className="list-disc pl-6 space-y-1">
                  <li>Garantir que o uso do Software esteja em conformidade com a legislação vigente, incluindo, mas não se limitando, a leis relacionadas à proteção de dados e à propriedade intelectual;</li>
                  <li>Não realizar ações que possam prejudicar a segurança ou a funcionalidade do Software;</li>
                  <li>Não utilizar o Software para fins ilícitos ou fraudulentos.</li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className={`text-xl font-semibold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
                Artigo 7 – Propriedade Intelectual
              </h2>
              <div className="space-y-2">
                <p>7.1. O Software, seus códigos, design, funcionalidades e conteúdo são de propriedade exclusiva da OPENFLOW, estando protegidos por leis de propriedade intelectual.</p>
                <p>7.2. O USUÁRIO não poderá reproduzir, modificar, distribuir ou usar o Software de forma não autorizada.</p>
                <p>7.3. A violação dos direitos de propriedade intelectual será passível de medidas legais cabíveis.</p>
              </div>
            </section>

            <section>
              <h2 className={`text-xl font-semibold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
                Artigo 8 – Coleta e Uso de Dados
              </h2>
              <div className="space-y-2">
                <p>8.1. A OPENFLOW coleta e utiliza dados fornecidos pelo USUÁRIO conforme estabelecido pela Lei Geral de Proteção de Dados (Lei nº 13.709/2018).</p>
                <p>8.2. O uso dos dados ocorre para:</p>
                <ul className="list-disc pl-6 space-y-1">
                  <li>Personalizar a experiência do USUÁRIO;</li>
                  <li>Melhorar os serviços do Software;</li>
                  <li>Fornecer suporte e atendimento ao cliente.</li>
                </ul>
                <p>8.3. A OPENFLOW adota medidas de segurança para proteger os dados do USUÁRIO, mas não se responsabiliza por falhas externas ou por ações de terceiros que possam comprometer a segurança.</p>
              </div>
            </section>

            <section>
              <h2 className={`text-xl font-semibold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
                Artigo 9 – Limitação de Responsabilidade
              </h2>
              <div className="space-y-2">
                <p>9.1. A OPENFLOW não será responsável por:</p>
                <ul className="list-disc pl-6 space-y-1">
                  <li>Danos ou prejuízos causados pelo uso indevido ou ilegal do Software pelo USUÁRIO;</li>
                  <li>Interrupções no acesso ao Software decorrentes de falhas técnicas ou problemas externos, como interrupção de serviços de internet ou ataques cibernéticos.</li>
                </ul>
                <p>9.2. Em nenhuma hipótese, a responsabilidade da OPENFLOW ultrapassará o valor pago pelo USUÁRIO no período de 12 meses anteriores ao evento que deu origem à reclamação.</p>
              </div>
            </section>

            <section>
              <h2 className={`text-xl font-semibold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
                Artigo 10 – Alterações nos Termos
              </h2>
              <div className="space-y-2">
                <p>10.1. A OPENFLOW poderá alterar os Termos a qualquer momento, com a devida notificação ao USUÁRIO, por meio de e-mail ou notificação no próprio Software.</p>
                <p>10.2. O uso contínuo do Software após a alteração implica aceitação dos novos Termos.</p>
              </div>
            </section>

            <section>
              <h2 className={`text-xl font-semibold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
                Contato
              </h2>
              <p>
                Para dúvidas ou suporte, entre em contato pelo e-mail{' '}
                <a 
                  href="mailto:suporte@openflow.com" 
                  className={`${isDark ? 'text-purple-400 hover:text-purple-300' : 'text-purple-500 hover:text-purple-600'} transition-colors duration-300`}
                >
                  suporte@openflow.com
                </a>
              </p>
            </section>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className={`${isDark ? 'bg-[#0B1121]' : 'bg-[#f8f8f8]'} border-t ${isDark ? 'border-purple-500/10' : 'border-purple-100'} mt-auto`}>
        <div className="container mx-auto px-6 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
            <div>
              <Link to="/" className="flex items-center gap-3 group">
                <div className="relative">
                  <div className={`w-10 h-10 ${isDark ? 'bg-[#6D28D9]' : 'bg-purple-500'} rounded-xl flex items-center justify-center overflow-hidden`}>
                    <X className="w-6 h-6 text-white relative z-10 group-hover:rotate-180 transition-transform duration-700" />
                  </div>
                </div>
                <div className="flex items-center">
                  <span className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>Open</span>
                  <span className={`text-2xl font-bold ${isDark ? 'text-[#7C3AED]' : 'text-purple-500'}`}>Flow</span>
                </div>
              </Link>
              <p className={`mt-4 text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
                Revolucionando a geração de leads com soluções alimentadas por IA.
              </p>
            </div>

            {footerSections.map((section, index) => (
              <div key={index}>
                <h3 className={`text-lg font-semibold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
                  {section.title}
                </h3>
                <ul className="space-y-2">
                  {section.links.map((link, linkIndex) => (
                    <li key={linkIndex}>
                      <Link
                        to={link.href}
                        className={`text-sm ${isDark ? 'text-purple-300 hover:text-purple-200' : 'text-purple-600 hover:text-purple-700'} transition-colors duration-300`}
                      >
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="mt-12 pt-8 border-t border-purple-500/10">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
              <p className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
                © 2025 OpenFlow. Todos os direitos reservados.
              </p>
              <div className="flex items-center gap-6">
                <a href="https://google.com" target="_blank" rel="noopener noreferrer" className="hover:opacity-80 transition-opacity">
                  <img src="https://www.google.com/favicon.ico" alt="Google" className="w-5 h-5" />
                </a>
                <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="hover:opacity-80 transition-opacity">
                  <img src="https://www.facebook.com/favicon.ico" alt="Facebook" className="w-5 h-5" />
                </a>
                <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="hover:opacity-80 transition-opacity">
                  <img src="https://www.linkedin.com/favicon.ico" alt="LinkedIn" className="w-5 h-5" />
                </a>
                <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="hover:opacity-80 transition-opacity">
                  <img src="https://twitter.com/favicon.ico" alt="Twitter" className="w-5 h-5" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}