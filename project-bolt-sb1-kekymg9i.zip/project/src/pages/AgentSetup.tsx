import React, { useState, useRef } from 'react';
import { X, Send, Image, Paperclip, Sun, Moon, User } from 'lucide-react';

interface AgentSetupProps {
  isDark: boolean;
}

export default function AgentSetup({ isDark: initialIsDark }: AgentSetupProps) {
  const [isDark, setIsDark] = useState(initialIsDark);
  const [message, setMessage] = useState('');
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    setMessage('');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    const allowedTypes = ['.png', '.jpg', '.jpeg', '.pdf'];
    const invalidFiles = Array.from(files).filter(file => {
      const extension = '.' + file.name.split('.').pop()?.toLowerCase();
      return !allowedTypes.includes(extension);
    });

    if (invalidFiles.length > 0) {
      alert('Apenas arquivos PNG, JPG, JPEG e PDF são permitidos.');
      return;
    }
  };

  const toggleTheme = () => {
    setIsDark(!isDark);
    document.documentElement.classList.toggle('dark');
  };

  return (
    <div className={`min-h-screen ${isDark ? 'bg-[#0B1121] bg-grid-pattern' : 'bg-[#f8f8f8] bg-grid-pattern-light'} flex flex-col`}>
      {/* Header */}
      <div className="flex items-center justify-between px-4 md:px-6 py-4">
        <div className="flex items-center gap-3">
          <div className={`w-10 h-10 ${isDark ? 'bg-[#6D28D9]' : 'bg-purple-500'} rounded-xl flex items-center justify-center`}>
            <X className="w-6 h-6 text-white" />
          </div>
          <div className="flex items-center">
            <span className={`text-xl md:text-2xl font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>Open</span>
            <span className={`text-xl md:text-2xl font-bold ${isDark ? 'text-[#7C3AED]' : 'text-purple-500'}`}>Flow</span>
          </div>
        </div>
        <div className="flex items-center gap-2 md:gap-4">
          <button
            onClick={toggleTheme}
            className={`p-2 rounded-lg ${isDark ? 'hover:bg-white/5' : 'hover:bg-gray-100'} transition-colors duration-300`}
          >
            {isDark ? (
              <Sun className="w-5 h-5 text-purple-400" />
            ) : (
              <Moon className="w-5 h-5 text-purple-500" />
            )}
          </button>
          <div className="relative">
            <button
              onClick={() => setShowProfileMenu(!showProfileMenu)}
              className={`w-8 h-8 rounded-lg ${isDark ? 'bg-purple-500/20' : 'bg-purple-100'} flex items-center justify-center`}
            >
              <User className={`w-5 h-5 ${isDark ? 'text-purple-400' : 'text-purple-500'}`} />
            </button>
            
            {showProfileMenu && (
              <div className={`absolute right-0 mt-2 w-48 rounded-xl shadow-lg ${isDark ? 'bg-[#1A1F2E]' : 'bg-white'} ring-1 ring-black ring-opacity-5 z-50`}>
                <div className="py-1">
                  <button
                    className={`block w-full text-left px-4 py-2 text-sm ${isDark ? 'text-purple-300 hover:bg-white/5' : 'text-purple-600 hover:bg-gray-100'}`}
                    onClick={() => setShowProfileMenu(false)}
                  >
                    Meu Perfil
                  </button>
                  <button
                    className={`block w-full text-left px-4 py-2 text-sm ${isDark ? 'text-purple-300 hover:bg-white/5' : 'text-purple-600 hover:bg-gray-100'}`}
                    onClick={() => setShowProfileMenu(false)}
                  >
                    Configurações
                  </button>
                  <button
                    className="block w-full text-left px-4 py-2 text-sm text-red-500 hover:bg-red-50"
                    onClick={() => setShowProfileMenu(false)}
                  >
                    Sair
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Chat Container */}
      <div className="flex-1 flex items-center justify-center p-4 md:px-6 md:py-4">
        <div className={`w-full max-w-4xl h-[calc(100vh-8rem)] ${isDark ? 'bg-[#1A1F2E]' : 'bg-white'} rounded-2xl shadow-lg flex flex-col`}>
          <div className="flex-1 p-4 md:p-6 overflow-y-auto">
            {/* Mensagem inicial do assistente */}
            <div className={`inline-block max-w-[90%] md:max-w-[70%] rounded-2xl px-4 py-3 ${isDark ? 'bg-[#232838] text-purple-300' : 'bg-purple-50 text-purple-600'}`}>
              Olá! Sou sua assistente especializada em configuração de agentes. Vou te ajudar a criar um agente personalizado que atenda perfeitamente às suas necessidades. Para começar, me conte um pouco sobre o principal objetivo do seu agente.
            </div>
          </div>

          {/* Input Area */}
          <div className="p-4 border-t border-purple-500/10">
            <form onSubmit={handleSendMessage} className="flex items-center gap-2">
              <div className="hidden md:flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className={`p-2 rounded-lg ${isDark ? 'hover:bg-white/5' : 'hover:bg-gray-100'} transition-colors duration-300`}
                  title="Enviar imagem"
                >
                  <Image className={`w-5 h-5 ${isDark ? 'text-purple-400' : 'text-purple-500'}`} />
                </button>
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className={`p-2 rounded-lg ${isDark ? 'hover:bg-white/5' : 'hover:bg-gray-100'} transition-colors duration-300`}
                  title="Anexar arquivo"
                >
                  <Paperclip className={`w-5 h-5 ${isDark ? 'text-purple-400' : 'text-purple-500'}`} />
                </button>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                  className="hidden"
                  multiple
                  accept=".png,.jpg,.jpeg,.pdf"
                />
              </div>
              
              <input
                type="text"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Digite sua mensagem..."
                className={`flex-1 px-4 py-3 ${
                  isDark ? 'bg-[#232838] text-white placeholder-white/30' : 'bg-purple-50 text-gray-900 placeholder-purple-300'
                } rounded-xl focus:outline-none focus:ring-2 ${
                  isDark ? 'focus:ring-purple-500/30' : 'focus:ring-purple-500/50'
                } transition-all duration-300`}
              />
              
              <button
                type="submit"
                className="p-2 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors duration-300"
              >
                <Send className="w-5 h-5" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}