import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  Send, 
  Star, 
  Users, 
  Zap,
  MessageSquare
} from 'lucide-react';

interface AgentDetailProps {
  isDark: boolean;
}

const agents = {
  delivery: {
    title: 'Agente para Delivery',
    description: 'Otimize suas entregas com um sistema inteligente de rastreamento em tempo real, gestão de rotas e monitoramento completo da sua frota.',
    price: 'R$ 199/mês',
    image: 'https://images.unsplash.com/photo-1526367790999-0150786686a2?auto=format&fit=crop&q=80&w=500',
    metrics: { rating: 4.8, users: '2.5k+', uptime: '99.9%', response: '0.5s' }
  },
  ecommerce: {
    title: 'Agente para E-commerce',
    description: 'Potencialize suas vendas online com um assistente virtual inteligente que oferece recomendações personalizadas e análise avançada do comportamento do cliente.',
    price: 'R$ 249/mês',
    image: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&q=80&w=500',
    metrics: { rating: 4.9, users: '3k+', uptime: '99.8%', response: '0.5s' }
  },
  hotel: {
    title: 'Agente para Hotelaria',
    description: 'Automatize a gestão do seu hotel com um sistema completo de reservas, check-in digital e atendimento 24/7 para proporcionar a melhor experiência aos seus hóspedes.',
    price: 'R$ 299/mês',
    image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&q=80&w=500',
    metrics: { rating: 4.7, users: '1.8k+', uptime: '99.7%', response: '0.5s' }
  },
  health: {
    title: 'Agente para Saúde',
    description: 'Revolucione o atendimento na área da saúde com agendamento inteligente, prontuário digital e sistema integrado de telemedicina para cuidar melhor dos seus pacientes.',
    price: 'R$ 349/mês',
    image: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&q=80&w=500',
    metrics: { rating: 4.9, users: '2.2k+', uptime: '99.9%', response: '0.5s' }
  },
  clinic: {
    title: 'Agente para Consultório',
    description: 'Gerencie seu consultório de forma eficiente com um sistema completo de agendamento, histórico de pacientes e faturamento automatizado.',
    price: 'R$ 179/mês',
    image: 'https://images.unsplash.com/photo-1516549655169-df83a0774514?auto=format&fit=crop&q=80&w=500',
    metrics: { rating: 4.6, users: '1.5k+', uptime: '99.5%', response: '0.5s' }
  },
  custom: {
    title: 'Agente Personalizado',
    description: 'Crie um agente sob medida para seu negócio com recursos personalizados, API customizada e suporte dedicado para atender suas necessidades específicas.',
    price: 'Sob consulta',
    image: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=500',
    metrics: { rating: 4.8, users: '500+', uptime: '99.9%', response: '0.5s' }
  }
};

export default function AgentDetail({ isDark }: AgentDetailProps) {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [message, setMessage] = useState('');
  const [chatMessages, setChatMessages] = useState<{type: 'user' | 'agent', content: string}[]>([]);
  const [hasStartedChat, setHasStartedChat] = useState(false);

  const agent = id ? agents[id as keyof typeof agents] : agents.ecommerce;

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    if (!hasStartedChat) {
      setHasStartedChat(true);
    }

    setChatMessages([...chatMessages, {type: 'user', content: message}]);
    setMessage('');

    setTimeout(() => {
      setChatMessages(prev => [...prev, {
        type: 'agent',
        content: 'Entendi sua solicitação. Como agente de IA, estou aqui para ajudar você da melhor forma possível.'
      }]);
    }, 1000);
  };

  const handlePurchase = () => {
    navigate(`/payment/${id}`);
  };

  return (
    <div className="min-h-screen pt-24 pb-12 pl-72 pr-8">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-12 gap-6">
          {/* Coluna da Esquerda - Informações do Agente */}
          <div className="col-span-4">
            <div className={`rounded-2xl ${isDark ? 'bg-[#1A1F2E]' : 'bg-white'} overflow-hidden`}>
              {/* Imagem do agente */}
              <div className="relative h-48">
                <img
                  src={agent.image}
                  alt={agent.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                <div className="absolute bottom-4 left-4 right-4">
                  <h2 className="text-2xl font-bold text-white">
                    {agent.title}
                  </h2>
                </div>
              </div>

              <div className="p-6">
                {/* Descrição */}
                <p className={`mb-6 ${isDark ? 'text-purple-300' : 'text-purple-600'} font-medium`}>
                  {agent.description}
                </p>

                {/* Métricas */}
                <div className={`p-6 rounded-xl ${isDark ? 'bg-[#232838]' : 'bg-purple-50'} mb-6`}>
                  <div className="grid grid-cols-3 gap-6">
                    <div className="text-center">
                      <div className="flex items-center justify-center mb-2">
                        <Star className={`w-5 h-5 ${isDark ? 'text-yellow-400' : 'text-yellow-500'}`} />
                      </div>
                      <p className={`text-xl font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>
                        {agent.metrics.rating}
                      </p>
                      <p className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
                        Rating
                      </p>
                    </div>
                    <div className="text-center">
                      <div className="flex items-center justify-center mb-2">
                        <Users className={`w-5 h-5 ${isDark ? 'text-purple-400' : 'text-purple-500'}`} />
                      </div>
                      <p className={`text-xl font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>
                        {agent.metrics.users}
                      </p>
                      <p className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
                        Usuários
                      </p>
                    </div>
                    <div className="text-center">
                      <div className="flex items-center justify-center mb-2">
                        <Zap className={`w-5 h-5 ${isDark ? 'text-green-400' : 'text-green-500'}`} />
                      </div>
                      <p className={`text-xl font-bold ${isDark ? 'text-white' : ' text-gray-900'}`}>
                        {agent.metrics.uptime}
                      </p>
                      <p className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
                        Uptime
                      </p>
                    </div>
                  </div>
                </div>

                {/* Preço */}
                <div className={`p-4 rounded-xl ${isDark ? 'bg-[#232838]' : 'bg-purple-50'} mb-6`}>
                  <p className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'} mb-1`}>Preço</p>
                  <p className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>{agent.price}</p>
                </div>

                <button 
                  onClick={handlePurchase}
                  className="w-full py-4 px-6 bg-purple-500 hover:bg-purple-600 text-white rounded-xl flex items-center justify-center gap-2 transition-all duration-300 transform hover:scale-[1.02] active:scale-[0.98]"
                >
                  <span className="font-medium">Adquirir Agente</span>
                </button>
              </div>
            </div>
          </div>

          {/* Coluna da Direita - Chat */}
          <div className="col-span-8">
            <div className={`rounded-2xl ${isDark ? 'bg-[#1A1F2E]' : 'bg-white'} p-6 h-[calc(100vh-8rem)] flex flex-col`}>
              <div className="flex-1 overflow-y-auto mb-4 space-y-4 relative">
                {!hasStartedChat && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <MessageSquare className={`w-12 h-12 ${isDark ? 'text-purple-400' : 'text-purple-500'} mx-auto mb-4`} />
                      <p className={`text-lg ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
                        Converse com nosso agente de IA
                      </p>
                    </div>
                  </div>
                )}
                {chatMessages.map((msg, index) => (
                  <div key={index} className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[70%] rounded-2xl px-4 py-3 ${
                      msg.type === 'user'
                        ? 'bg-purple-500 text-white'
                        : isDark
                        ? 'bg-[#232838] text-purple-300'
                        : 'bg-purple-50 text-purple-600'
                    }`}>
                      {msg.content}
                    </div>
                  </div>
                ))}
              </div>

              <form onSubmit={handleSendMessage} className="relative">
                <input
                  type="text"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Digite sua mensagem..."
                  className={`w-full pl-4 pr-12 py-4 ${
                    isDark ? 'bg-[#232838] text-white placeholder-white/30' : 'bg-purple-50 text-gray-900 placeholder-purple-300'
                  } rounded-xl focus:outline-none focus:ring-2 ${
                    isDark ? 'focus:ring-purple-500/30' : 'focus:ring-purple-500/50'
                  } transition-all duration-300`}
                />
                <button
                  type="submit"
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors duration-300"
                >
                  <Send className="w-5 h-5" />
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}