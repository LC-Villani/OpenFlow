import React, { useState } from 'react';
import { Lock, ArrowRight } from 'lucide-react';
import AuthNavbar from '../components/AuthNavbar';

interface ResetPasswordProps {
  isDark: boolean;
  toggleTheme: () => void;
}

export default function ResetPassword({ isDark, toggleTheme }: ResetPasswordProps) {
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const getPasswordStrength = (pass: string) => {
    if (!pass) return 0;
    let strength = 0;
    if (pass.length >= 8) strength++;
    if (/[A-Z]/.test(pass)) strength++;
    if (/[0-9]/.test(pass)) strength++;
    if (/[^A-Za-z0-9]/.test(pass)) strength++;
    return strength;
  };

  const passwordStrength = getPasswordStrength(password);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => setIsLoading(false), 2000);
  };

  return (
    <>
      <AuthNavbar isDark={isDark} toggleTheme={toggleTheme} />
      <div className="container mx-auto px-4 py-8 pt-24">
        <div className="max-w-md mx-auto">
          <div className="relative">
            <div className={`absolute -inset-0.5 ${isDark ? 'bg-purple-600' : 'bg-purple-200'} rounded-3xl blur opacity-30`}></div>
            
            <div className={`relative ${isDark ? 'bg-[#1A1F2E]' : 'bg-white'} rounded-3xl p-8 space-y-8 ${!isDark && 'shadow-xl'}`}>
              <div className="text-center space-y-2">
                <h2 className={`text-3xl font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>Redefinir senha</h2>
                <p className={isDark ? 'text-purple-300' : 'text-purple-500'}>Crie uma nova senha segura para sua conta</p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="relative">
                      <input
                        type="password"
                        placeholder="Nova senha"
                        className={`w-full pl-4 pr-12 py-4 ${isDark ? 'bg-[#232838]' : 'bg-white'} rounded-xl ${isDark ? 'text-white' : 'text-gray-900'} border ${isDark ? 'border-purple-500/20' : 'border-purple-100'} focus:outline-none focus:ring-2 ${isDark ? 'focus:ring-purple-500/30' : 'focus:ring-purple-500/50'} transition-all duration-300`}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                      />
                      <Lock className={`absolute right-4 top-1/2 -translate-y-1/2 ${isDark ? 'text-purple-400' : 'text-purple-500'}`} size={20} />
                    </div>
                    
                    <div className="flex gap-2">
                      {[...Array(4)].map((_, i) => (
                        <div
                          key={i}
                          className={`h-1 flex-1 rounded-full transition-colors duration-300 ${
                            i < passwordStrength
                              ? [
                                  'bg-red-500',
                                  'bg-orange-500',
                                  'bg-yellow-500',
                                  'bg-green-500',
                                ][passwordStrength - 1]
                              : isDark ? 'bg-purple-500/20' : 'bg-purple-100'
                          }`}
                        />
                      ))}
                    </div>
                  </div>

                  <div className="relative">
                    <input
                      type="password"
                      placeholder="Confirme a nova senha"
                      className={`w-full pl-4 pr-12 py-4 ${isDark ? 'bg-[#232838]' : 'bg-white'} rounded-xl ${isDark ? 'text-white' : 'text-gray-900'} border ${isDark ? 'border-purple-500/20' : 'border-purple-100'} focus:outline-none focus:ring-2 ${isDark ? 'focus:ring-purple-500/30' : 'focus:ring-purple-500/50'} transition-all duration-300`}
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                    />
                    <Lock className={`absolute right-4 top-1/2 -translate-y-1/2 ${isDark ? 'text-purple-400' : 'text-purple-500'}`} size={20} />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={!password || password !== confirmPassword || isLoading}
                  className="group relative w-full overflow-hidden bg-purple-500 rounded-xl p-4 transition-all duration-300 hover:bg-purple-600 active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <div className="relative flex items-center justify-center gap-2">
                    <span className="text-white font-medium">
                      {isLoading ? 'Atualizando...' : 'Atualizar senha'}
                    </span>
                    <ArrowRight 
                      className={`w-5 h-5 text-white transition-all duration-300 ${
                        isLoading ? 'animate-spin' : 'group-hover:translate-x-1'
                      }`}
                    />
                  </div>
                </button>

                <p className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-500'} text-center`}>
                  Sua nova senha será ativada imediatamente após a atualização
                </p>
              </form>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}