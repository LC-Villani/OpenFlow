import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle2 } from 'lucide-react';

interface PaymentSuccessProps {
  isDark: boolean;
}

export default function PaymentSuccess({ isDark }: PaymentSuccessProps) {
  const navigate = useNavigate();

  useEffect(() => {
    const timer = setTimeout(() => {
      navigate('/agent-setup');
    }, 5000);

    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className={`max-w-md w-full ${isDark ? 'bg-[#1A1F2E]' : 'bg-white'} rounded-2xl p-8 text-center`}>
        <div className="mb-6">
          <div className="w-20 h-20 mx-auto bg-green-500 rounded-full flex items-center justify-center mb-4">
            <CheckCircle2 className="w-12 h-12 text-white" />
          </div>
          <h2 className={`text-2xl font-bold mb-2 ${isDark ? 'text-white' : 'text-gray-900'}`}>
            Pagamento Aprovado!
          </h2>
          <p className={`${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
            Você será redirecionado para a configuração do seu agente em alguns segundos...
          </p>
        </div>

        <div className="w-full bg-gray-200 h-1 rounded-full overflow-hidden">
          <div className="h-full bg-green-500 animate-[progress_5s_linear]" />
        </div>
      </div>
    </div>
  );
}