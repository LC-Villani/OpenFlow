import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Settings2, 
  MessageSquare, 
  Image, 
  List, 
  Phone, 
  CreditCard, 
  MessageCircle, 
  ShoppingBag, 
  Lock,
  ArrowRight,
  Check
} from 'lucide-react';

interface PurchaseProps {
  isDark: boolean;
}

type ContentType = 'text' | 'media' | 'quickReply' | 'callToAction' | 'listPicker' | 'card' | 'whatsappCard' | 'authentication' | 'catalog';

const agentTypes = {
  text: 'Agente de Texto',
  media: 'Agente de Mídia',
  quickReply: 'Agente de Resposta Rápida',
  callToAction: 'Agente de Chamada para Ação',
  listPicker: 'Agente de Lista',
  card: 'Agente de Cartão',
  whatsappCard: 'Agente de WhatsApp',
  authentication: 'Agente de Autenticação',
  catalog: 'Agente de Catálogo'
};

interface Channel {
  id: string;
  name: string;
  icon: string;
  description: string;
  available: boolean;
}

const channelsByType: Record<ContentType, Channel[]> = {
  text: [
    { id: 'sms', name: 'SMS', icon: 'https://cdn-icons-png.flaticon.com/512/3077/3077393.png', description: 'Este template pode ser usado', available: true },
    { id: 'facebook', name: 'Facebook Messenger', icon: 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Facebook_Messenger_logo_2020.svg/2048px-Facebook_Messenger_logo_2020.svg.png', description: 'Este template pode ser usado', available: true },
    { id: 'whatsapp_user', name: 'WhatsApp user initiated', icon: 'https://cdn-icons-png.flaticon.com/512/3670/3670051.png', description: 'WhatsApp aprovado. Este template pode ser usado', available: true },
    { id: 'whatsapp_business', name: 'WhatsApp business initiated', icon: 'https://cdn-icons-png.flaticon.com/512/3670/3670051.png', description: 'WhatsApp approval required for this template to be used for WhatsApp business initiated messages', available: true }
  ],
  media: [
    { id: 'facebook', name: 'Facebook Messenger', icon: 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Facebook_Messenger_logo_2020.svg/2048px-Facebook_Messenger_logo_2020.svg.png', description: 'Este template pode ser usado', available: true },
    { id: 'whatsapp_user', name: 'WhatsApp user initiated', icon: 'https://cdn-icons-png.flaticon.com/512/3670/3670051.png', description: 'WhatsApp aprovado. Este template pode ser usado', available: true },
    { id: 'whatsapp_business', name: 'WhatsApp business initiated', icon: 'https://cdn-icons-png.flaticon.com/512/3670/3670051.png', description: 'WhatsApp approval required for this template to be used for WhatsApp business initiated messages', available: true }
  ],
  quickReply: [
    { id: 'facebook', name: 'Facebook Messenger', icon: 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Facebook_Messenger_logo_2020.svg/2048px-Facebook_Messenger_logo_2020.svg.png', description: 'Este template pode ser usado', available: true },
    { id: 'whatsapp_user', name: 'WhatsApp user initiated', icon: 'https://cdn-icons-png.flaticon.com/512/3670/3670051.png', description: 'WhatsApp aprovado. Este template pode ser usado', available: true },
    { id: 'whatsapp_business', name: 'WhatsApp business initiated', icon: 'https://cdn-icons-png.flaticon.com/512/3670/3670051.png', description: 'WhatsApp approval required for this template to be used for WhatsApp business initiated messages', available: true }
  ],
  callToAction: [
    { id: 'facebook', name: 'Facebook Messenger', icon: 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Facebook_Messenger_logo_2020.svg/2048px-Facebook_Messenger_logo_2020.svg.png', description: 'Este template pode ser usado', available: true },
    { id: 'whatsapp_user', name: 'WhatsApp user initiated', icon: 'https://cdn-icons-png.flaticon.com/512/3670/3670051.png', description: 'WhatsApp aprovado. Este template pode ser usado', available: true },
    { id: 'whatsapp_business', name: 'WhatsApp business initiated', icon: 'https://cdn-icons-png.flaticon.com/512/3670/3670051.png', description: 'WhatsApp approval required for this template to be used for WhatsApp business initiated messages', available: true }
  ],
  listPicker: [
    { id: 'facebook', name: 'Facebook Messenger', icon: 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Facebook_Messenger_logo_2020.svg/2048px-Facebook_Messenger_logo_2020.svg.png', description: 'Este template pode ser usado', available: true },
    { id: 'whatsapp_user', name: 'WhatsApp user initiated', icon: 'https://cdn-icons-png.flaticon.com/512/3670/3670051.png', description: 'WhatsApp aprovado. Este template pode ser usado', available: true }
  ],
  card: [
    { id: 'facebook', name: 'Facebook Messenger', icon: 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Facebook_Messenger_logo_2020.svg/2048px-Facebook_Messenger_logo_2020.svg.png', description: 'Este template pode ser usado', available: true },
    { id: 'whatsapp_user', name: 'WhatsApp user initiated', icon: 'https://cdn-icons-png.flaticon.com/512/3670/3670051.png', description: 'WhatsApp aprovado. Este template pode ser usado', available: true },
    { id: 'whatsapp_business', name: 'WhatsApp business initiated', icon: 'https://cdn-icons-png.flaticon.com/512/3670/3670051.png', description: 'WhatsApp approval required for this template', available: true }
  ],
  whatsappCard: [
    { id: 'whatsapp_user', name: 'WhatsApp user initiated', icon: 'https://cdn-icons-png.flaticon.com/512/3670/3670051.png', description: 'WhatsApp aprovado. Este template pode ser usado', available: true },
    { id: 'whatsapp_business', name: 'WhatsApp business initiated', icon: 'https://cdn-icons-png.flaticon.com/512/3670/3670051.png', description: 'WhatsApp approval required for this template to be used for WhatsApp business initiated messages', available: true }
  ],
  authentication: [
    { id: 'sms', name: 'SMS', icon: 'https://cdn-icons-png.flaticon.com/512/3077/3077393.png', description: 'Este template pode ser usado', available: true },
    { id: 'facebook', name: 'Facebook Messenger', icon: 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Facebook_Messenger_logo_2020.svg/2048px-Facebook_Messenger_logo_2020.svg.png', description: 'Este template pode ser usado', available: true },
    { id: 'whatsapp_user', name: 'WhatsApp user initiated', icon: 'https://cdn-icons-png.flaticon.com/512/3670/3670051.png', description: 'WhatsApp aprovado. Este template pode ser usado', available: true },
    { id: 'whatsapp_business', name: 'WhatsApp business initiated', icon: 'https://cdn-icons-png.flaticon.com/512/3670/3670051.png', description: 'WhatsApp approval required for this template to be used for WhatsApp business initiated messages', available: true }
  ],
  catalog: [
    { id: 'whatsapp_user', name: 'WhatsApp user initiated', icon: 'https://cdn-icons-png.flaticon.com/512/3670/3670051.png', description: 'WhatsApp aprovado. Este template pode ser usado', available: true },
    { id: 'whatsapp_business', name: 'WhatsApp business initiated', icon: 'https://cdn-icons-png.flaticon.com/512/3670/3670051.png', description: 'WhatsApp approval required for this template to be used for WhatsApp business initiated messages', available: true }
  ]
};

export default function Purchase({ isDark }: PurchaseProps) {
  const navigate = useNavigate();
  const [agentName, setAgentName] = useState('');
  const [selectedType, setSelectedType] = useState<ContentType>('text');

  const contentTypes = [
    { id: 'text' as ContentType, label: 'Texto', icon: MessageSquare, description: 'Agente especializado em comunicação textual' },
    { id: 'media' as ContentType, label: 'Mídia', icon: Image, description: 'Agente para gerenciamento de conteúdo multimídia' },
    { id: 'quickReply' as ContentType, label: 'Resposta Rápida', icon: MessageCircle, description: 'Agente para respostas automatizadas' },
    { id: 'callToAction' as ContentType, label: 'Chamada para Ação', icon: Phone, description: 'Agente para conversão de leads' },
    { id: 'listPicker' as ContentType, label: 'Seletor de Lista', icon: List, description: 'Agente para organização de opções' },
    { id: 'card' as ContentType, label: 'Cartão', icon: CreditCard, description: 'Agente para processamento de pagamentos' },
    { id: 'whatsappCard' as ContentType, label: 'Cartão WhatsApp', icon: MessageCircle, description: 'Agente para integração com WhatsApp' },
    { id: 'authentication' as ContentType, label: 'Autenticação', icon: Lock, description: 'Agente para segurança e verificação' },
    { id: 'catalog' as ContentType, label: 'Catálogo', icon: ShoppingBag, description: 'Agente para gestão de produtos' },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newAgent = {
      id: Date.now(),
      name: agentName,
      type: agentTypes[selectedType],
      createdAt: new Date().toISOString()
    };

    const existingAgents = JSON.parse(localStorage.getItem('agents') || '[]');
    localStorage.setItem('agents', JSON.stringify([...existingAgents, newAgent]));
    
    navigate('/agents');
  };

  return (
    <div className="min-h-screen pt-24 pb-12 pl-72 pr-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-12">
          <h1 className={`text-4xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
            Criar Agente
          </h1>
          <p className={`text-xl ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
            Configure seu agente personalizado
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Informações Gerais */}
          <section className={`p-6 rounded-2xl ${isDark ? 'bg-[#1A1F2E]' : 'bg-white'}`}>
            <div className="flex items-center gap-3 mb-6">
              <div className={`w-12 h-12 rounded-xl ${isDark ? 'bg-purple-500/20' : 'bg-purple-100'} flex items-center justify-center`}>
                <Settings2 className={`w-6 h-6 ${isDark ? 'text-purple-400' : 'text-purple-500'}`} />
              </div>
              <div>
                <h2 className={`text-xl font-semibold ${isDark ? 'text-white' : 'text-gray-900'}`}>
                  Informações Gerais
                </h2>
                <p className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
                  Configure as informações básicas do agente
                </p>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className={`block text-sm font-medium mb-2 ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
                  Nome do Agente
                </label>
                <input
                  type="text"
                  value={agentName}
                  onChange={(e) => setAgentName(e.target.value)}
                  placeholder="Ex: Agente de Vendas"
                  className={`w-full px-4 py-3 ${isDark ? 'bg-[#232838]' : 'bg-purple-50'} rounded-xl ${isDark ? 'text-white' : 'text-gray-900'} focus:outline-none focus:ring-2 ${isDark ? 'focus:ring-purple-500/30' : 'focus:ring-purple-500/50'} transition-all duration-300`}
                />
              </div>
            </div>
          </section>

          {/* Tipo de Agente */}
          <section className={`p-6 rounded-2xl ${isDark ? 'bg-[#1A1F2E]' : 'bg-white'}`}>
            <div className="flex items-center gap-3 mb-6">
              <div className={`w-12 h-12 rounded-xl ${isDark ? 'bg-purple-500/20' : 'bg-purple-100'} flex items-center justify-center`}>
                <MessageSquare className={`w-6 h-6 ${isDark ? 'text-purple-400' : 'text-purple-500'}`} />
              </div>
              <div>
                <h2 className={`text-xl font-semibold ${isDark ? 'text-white' : 'text-gray-900'}`}>
                  Tipo de Agente
                </h2>
                <p className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
                  Escolha a especialidade do seu agente
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {contentTypes.map((type) => {
                const Icon = type.icon;
                return (
                  <button
                    key={type.id}
                    type="button"
                    onClick={() => setSelectedType(type.id)}
                    className={`p-4 rounded-xl border-2 transition-all duration-300 flex flex-col items-center gap-2 ${
                      selectedType === type.id
                        ? isDark
                          ? 'bg-purple-500/20 border-purple-500'
                          : 'bg-purple-50 border-purple-500'
                        : isDark
                        ? 'bg-[#232838] border-purple-500/20 hover:border-purple-500/40'
                        : 'bg-purple-50/50 border-purple-200 hover:border-purple-300'
                    }`}
                  >
                    <Icon className={selectedType === type.id ? 'text-purple-500' : isDark ? 'text-purple-400' : 'text-purple-500'} />
                    <span className={`text-sm font-medium ${isDark ? 'text-white' : 'text-gray-900'}`}>{type.label}</span>
                    <p className={`text-xs text-center ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
                      {type.description}
                    </p>
                  </button>
                );
              })}
            </div>
          </section>

          {/* Canais Suportados */}
          <section className={`p-6 rounded-2xl ${isDark ? 'bg-[#1A1F2E]' : 'bg-white'}`}>
            <div className="flex items-center gap-3 mb-6">
              <div className={`w-12 h-12 rounded-xl ${isDark ? 'bg-purple-500/20' : 'bg-purple-100'} flex items-center justify-center`}>
                <MessageCircle className={`w-6 h-6 ${isDark ? 'text-purple-400' : 'text-purple-500'}`} />
              </div>
              <div>
                <h2 className={`text-xl font-semibold ${isDark ? 'text-white' : 'text-gray-900'}`}>
                  Canais Suportados
                </h2>
                <p className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
                  Canais disponíveis para este tipo de agente
                </p>
              </div>
            </div>

            {selectedType === 'catalog' && (
              <div className="mb-4">
                <h3 className={`text-md font-medium mb-2 ${isDark ? 'text-white' : 'text-gray-900'}`}>
                  Single Product, and Multi-Product Message
                </h3>
              </div>
            )}

            <div className="space-y-4">
              {channelsByType[selectedType].map((channel) => (
                <div 
                  key={channel.id}
                  className={`flex items-center gap-4 p-4 rounded-xl ${
                    isDark ? 'bg-[#232838]' : 'bg-purple-50'
                  } ${!channel.available && 'opacity-60'}`}
                >
                  <img 
                    src={channel.icon} 
                    alt={channel.name} 
                    className="w-10 h-10 object-contain"
                  />
                  <div className="flex-1">
                    <h3 className={`font-medium ${isDark ? 'text-white' : 'text-gray-900'}`}>
                      {channel.name}
                    </h3>
                    <p className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
                      {channel.description}
                    </p>
                  </div>
                  {channel.available ? (
                    <div className="flex items-center gap-1 text-green-500">
                      <Check size={16} />
                      <span className="text-sm">Disponível</span>
                    </div>
                  ) : (
                    <span className="text-sm text-red-500">Não disponível</span>
                  )}
                </div>
              ))}
            </div>

            {selectedType === 'catalog' && (
              <div className="mt-6">
                <h3 className={`text-md font-medium mb-2 ${isDark ? 'text-white' : 'text-gray-900'}`}>
                  Catalog Message
                </h3>
                <div className="space-y-4">
                  <div className={`flex items-center gap-4 p-4 rounded-xl ${isDark ? 'bg-[#232838]' : 'bg-purple-50'}`}>
                    <img 
                      src="https://cdn-icons-png.flaticon.com/512/3670/3670051.png" 
                      alt="WhatsApp business initiated" 
                      className="w-10 h-10 object-contain"
                    />
                    <div className="flex-1">
                      <h3 className={`font-medium ${isDark ? 'text-white' : 'text-gray-900'}`}>
                        WhatsApp business initiated
                      </h3>
                      <p className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
                        WhatsApp approval required for this template to be used for WhatsApp business initiated messages
                      </p>
                    </div>
                    <div className="flex items-center gap-1 text-green-500">
                      <Check size={16} />
                      <span className="text-sm">Disponível</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </section>

          {/* Botões de Ação */}
          <div className="flex justify-end gap-4">
            <button
              type="button"
              onClick={() => navigate('/agents')}
              className={`px-6 py-3 rounded-xl ${
                isDark ? 'bg-[#232838] text-purple-300 hover:bg-[#2A303F]' : 'bg-purple-50 text-purple-600 hover:bg-purple-100'
              } transition-all duration-300`}
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={!agentName.trim()}
              className="px-6 py-3 bg-purple-500 text-white rounded-xl hover:bg-purple-600 transition-all duration-300 flex items-center gap-2 group disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <span>Criar Agente</span>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
            </button>
            <button
              type="button"
              onClick={() => navigate('/home')}
              className="px-6 py-3 bg-green-500 text-white rounded-xl hover:bg-green-600 transition-all duration-300 flex items-center gap-2 group"
            >
              <span>Comprar Agente</span>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}