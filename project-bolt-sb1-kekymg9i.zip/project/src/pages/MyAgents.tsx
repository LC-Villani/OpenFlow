import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ShoppingBag, ArrowRight, MessageSquare, Calendar, Zap, Trash2, AlertTriangle } from 'lucide-react';

interface MyAgentsProps {
  isDark: boolean;
}

interface Agent {
  id: number;
  name: string;
  type: string;
  createdAt: string;
}

export default function MyAgents({ isDark }: MyAgentsProps) {
  const [agents, setAgents] = useState<Agent[]>(JSON.parse(localStorage.getItem('agents') || '[]'));
  const [deleteConfirm, setDeleteConfirm] = useState<number | null>(null);

  const handleDelete = (id: number) => {
    const updatedAgents = agents.filter(agent => agent.id !== id);
    localStorage.setItem('agents', JSON.stringify(updatedAgents));
    setAgents(updatedAgents);
    setDeleteConfirm(null);
  };

  if (agents.length === 0) {
    return (
      <div className="min-h-screen pt-24 pb-12 pl-72 pr-8">
        <div className="max-w-4xl mx-auto">
          <div className="flex flex-col items-center justify-center text-center">
            <div className={`w-20 h-20 ${isDark ? 'bg-purple-500/20' : 'bg-purple-100'} rounded-2xl flex items-center justify-center mb-6`}>
              <ShoppingBag className={`w-10 h-10 ${isDark ? 'text-purple-400' : 'text-purple-500'}`} />
            </div>

            <h1 className={`text-3xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
              Nenhum agente encontrado
            </h1>
            
            <p className={`text-lg mb-8 max-w-lg ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
              Você ainda não possui nenhum agente SDR. Adquira seu primeiro agente para começar a otimizar suas vendas.
            </p>

            <Link
              to="/purchase"
              className="inline-flex items-center gap-2 px-6 py-3 bg-purple-500 text-white rounded-xl hover:bg-purple-600 transition-all duration-300 group"
            >
              <span>Adquirir um agente</span>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-24 pb-12 pl-72 pr-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-12 flex justify-between items-center">
          <div>
            <h1 className={`text-4xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
              Meus Agentes
            </h1>
            <p className={`text-xl ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
              Gerencie seus agentes SDR
            </p>
          </div>
          <Link
            to="/purchase"
            className="inline-flex items-center gap-2 px-6 py-3 bg-purple-500 text-white rounded-xl hover:bg-purple-600 transition-all duration-300 group"
          >
            <span>Novo Agente</span>
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {agents.map((agent) => (
            <div
              key={agent.id}
              className={`group relative overflow-hidden rounded-2xl ${
                isDark ? 'bg-[#1A1F2E]' : 'bg-white'
              } hover:shadow-xl transition-all duration-300 p-6`}
            >
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-xl ${isDark ? 'bg-purple-500/20' : 'bg-purple-100'} flex items-center justify-center`}>
                    <MessageSquare className={`w-6 h-6 ${isDark ? 'text-purple-400' : 'text-purple-500'}`} />
                  </div>
                  <div>
                    <h3 className={`text-xl font-semibold ${isDark ? 'text-white' : 'text-gray-900'}`}>
                      {agent.name}
                    </h3>
                    <p className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
                      {agent.type}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setDeleteConfirm(agent.id)}
                  className={`p-2 rounded-lg transition-colors duration-300 ${
                    isDark 
                      ? 'hover:bg-red-500/10 text-red-400 hover:text-red-300' 
                      : 'hover:bg-red-50 text-red-500 hover:text-red-600'
                  }`}
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>

              <div className="flex items-center gap-4 mb-6">
                <div className="flex items-center gap-2">
                  <Calendar className={`w-4 h-4 ${isDark ? 'text-purple-400' : 'text-purple-500'}`} />
                  <span className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
                    {new Date(agent.createdAt).toLocaleDateString()}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Zap className={`w-4 h-4 ${isDark ? 'text-green-400' : 'text-green-500'}`} />
                  <span className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
                    Ativo
                  </span>
                </div>
              </div>

              <button
                className={`w-full py-3 rounded-xl ${
                  isDark ? 'bg-[#232838] text-purple-300 hover:bg-[#2A303F]' : 'bg-purple-50 text-purple-600 hover:bg-purple-100'
                } transition-all duration-300`}
              >
                Gerenciar Agente
              </button>

              {/* Delete Confirmation Modal */}
              {deleteConfirm === agent.id && (
                <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
                  <div className={`w-full max-w-md p-6 rounded-2xl ${isDark ? 'bg-[#1A1F2E]' : 'bg-white'}`}>
                    <div className="flex items-start gap-3 mb-6">
                      <AlertTriangle className="w-6 h-6 text-red-500 flex-shrink-0" />
                      <div>
                        <h3 className={`text-xl font-semibold mb-2 ${isDark ? 'text-white' : 'text-gray-900'}`}>
                          Excluir Agente
                        </h3>
                        <p className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
                          Tem certeza que deseja excluir o agente "{agent.name}"? Esta ação não pode ser desfeita.
                        </p>
                      </div>
                    </div>
                    <div className="flex justify-end gap-3">
                      <button
                        onClick={() => setDeleteConfirm(null)}
                        className={`px-4 py-2 rounded-lg ${
                          isDark 
                            ? 'bg-[#232838] text-purple-300 hover:bg-[#2A303F]' 
                            : 'bg-purple-50 text-purple-600 hover:bg-purple-100'
                        } transition-all duration-300`}
                      >
                        Cancelar
                      </button>
                      <button
                        onClick={() => handleDelete(agent.id)}
                        className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-all duration-300"
                      >
                        Excluir
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}