import React, { useState } from 'react';
import { Settings2, MessageSquare, Image, List, Phone, CreditCard, MessageCircle, ShoppingBag, Lock, ArrowRight } from 'lucide-react';

interface TemplateProps {
  isDark: boolean;
}

type ContentType = 'text' | 'media' | 'quickReply' | 'callToAction' | 'listPicker' | 'card' | 'whatsappCard' | 'authentication' | 'catalog';

export default function Template({ isDark }: TemplateProps) {
  const [templateName, setTemplateName] = useState('');
  const [selectedType, setSelectedType] = useState<ContentType>('text');

  const contentTypes = [
    { id: 'text' as ContentType, label: 'Texto', icon: MessageSquare },
    { id: 'media' as ContentType, label: 'Mídia', icon: Image },
    { id: 'quickReply' as ContentType, label: 'Resposta Rápida', icon: MessageCircle },
    { id: 'callToAction' as ContentType, label: 'Chamada para Ação', icon: Phone },
    { id: 'listPicker' as ContentType, label: 'Seletor de Lista', icon: List },
    { id: 'card' as ContentType, label: 'Cartão', icon: CreditCard },
    { id: 'whatsappCard' as ContentType, label: 'Cartão WhatsApp', icon: MessageCircle },
    { id: 'authentication' as ContentType, label: 'Autenticação', icon: Lock },
    { id: 'catalog' as ContentType, label: 'Catálogo', icon: ShoppingBag },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Implementar lógica de criação do template
    console.log({ templateName, selectedType });
  };

  return (
    <div className="min-h-screen pt-24 pb-12 pl-72 pr-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-12">
          <h1 className={`text-4xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
            Criar Template
          </h1>
          <p className={`text-xl ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
            Configure seu template personalizado
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Informações Gerais */}
          <section className={`p-6 rounded-2xl ${isDark ? 'bg-[#1A1F2E]' : 'bg-white'}`}>
            <div className="flex items-center gap-3 mb-6">
              <div className={`w-12 h-12 rounded-xl ${isDark ? 'bg-purple-500/20' : 'bg-purple-100'} flex items-center justify-center`}>
                <Settings2 className={`w-6 h-6 ${isDark ? 'text-purple-400' : 'text-purple-500'}`} />
              </div>
              <div>
                <h2 className={`text-xl font-semibold ${isDark ? 'text-white' : 'text-gray-900'}`}>
                  Informações Gerais
                </h2>
                <p className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
                  Configure as informações básicas do template
                </p>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className={`block text-sm font-medium mb-2 ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
                  Nome do Template
                </label>
                <input
                  type="text"
                  value={templateName}
                  onChange={(e) => setTemplateName(e.target.value)}
                  placeholder="Ex: confirmacao_pedido"
                  className={`w-full px-4 py-3 ${isDark ? 'bg-[#232838]' : 'bg-purple-50'} rounded-xl ${isDark ? 'text-white' : 'text-gray-900'} focus:outline-none focus:ring-2 ${isDark ? 'focus:ring-purple-500/30' : 'focus:ring-purple-500/50'} transition-all duration-300`}
                />
                <p className={`mt-2 text-sm ${isDark ? 'text-purple-400' : 'text-purple-500'}`}>
                  Use apenas letras minúsculas, números e underscores
                </p>
              </div>

              <div>
                <label className={`block text-sm font-medium mb-2 ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
                  Idioma
                </label>
                <select
                  className={`w-full px-4 py-3 ${isDark ? 'bg-[#232838]' : 'bg-purple-50'} rounded-xl ${isDark ? 'text-white' : 'text-gray-900'} focus:outline-none focus:ring-2 ${isDark ? 'focus:ring-purple-500/30' : 'focus:ring-purple-500/50'} transition-all duration-300`}
                >
                  <option value="pt_BR">Português (Brasil)</option>
                  <option value="en">English</option>
                  <option value="es">Español</option>
                </select>
              </div>
            </div>
          </section>

          {/* Tipo de Conteúdo */}
          <section className={`p-6 rounded-2xl ${isDark ? 'bg-[#1A1F2E]' : 'bg-white'}`}>
            <div className="flex items-center gap-3 mb-6">
              <div className={`w-12 h-12 rounded-xl ${isDark ? 'bg-purple-500/20' : 'bg-purple-100'} flex items-center justify-center`}>
                <MessageSquare className={`w-6 h-6 ${isDark ? 'text-purple-400' : 'text-purple-500'}`} />
              </div>
              <div>
                <h2 className={`text-xl font-semibold ${isDark ? 'text-white' : 'text-gray-900'}`}>
                  Tipo de Conteúdo
                </h2>
                <p className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
                  Escolha o tipo de mensagem para seu template
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {contentTypes.map((type) => {
                const Icon = type.icon;
                return (
                  <button
                    key={type.id}
                    type="button"
                    onClick={() => setSelectedType(type.id)}
                    className={`p-4 rounded-xl border-2 transition-all duration-300 flex flex-col items-center gap-2 ${
                      selectedType === type.id
                        ? isDark
                          ? 'bg-purple-500/20 border-purple-500'
                          : 'bg-purple-50 border-purple-500'
                        : isDark
                        ? 'bg-[#232838] border-purple-500/20 hover:border-purple-500/40'
                        : 'bg-purple-50/50 border-purple-200 hover:border-purple-300'
                    }`}
                  >
                    <Icon className={selectedType === type.id ? 'text-purple-500' : isDark ? 'text-purple-400' : 'text-purple-500'} />
                    <span className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>{type.label}</span>
                  </button>
                );
              })}
            </div>
          </section>

          {/* Botões de Ação */}
          <div className="flex justify-end gap-4">
            <button
              type="button"
              className={`px-6 py-3 rounded-xl ${
                isDark ? 'bg-[#232838] text-purple-300 hover:bg-[#2A303F]' : 'bg-purple-50 text-purple-600 hover:bg-purple-100'
              } transition-all duration-300`}
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-6 py-3 bg-purple-500 text-white rounded-xl hover:bg-purple-600 transition-all duration-300 flex items-center gap-2 group"
            >
              <span>Criar Template</span>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}