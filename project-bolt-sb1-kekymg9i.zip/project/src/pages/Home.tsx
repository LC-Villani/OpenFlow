import React from 'react';
import { Link } from 'react-router-dom';
import { Star, Users, Zap } from 'lucide-react';

interface HomeProps {
  isDark: boolean;
}

const agents = [
  {
    id: 'delivery',
    title: 'Agente para Delivery',
    description: 'Otimize suas entregas com IA',
    price: 'R$ 199/mês',
    image: 'https://images.unsplash.com/photo-1526367790999-0150786686a2?auto=format&fit=crop&q=80&w=500',
    metrics: {
      rating: 4.8,
      users: '2.5k+',
      uptime: '99.9%'
    },
    features: ['Rastreamento em tempo real', 'Otimização de rotas', 'Gestão de frota']
  },
  {
    id: 'ecommerce',
    title: 'Agente para E-commerce',
    description: 'Aumente suas vendas online',
    price: 'R$ 249/mês',
    image: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&q=80&w=500',
    metrics: {
      rating: 4.9,
      users: '3k+',
      uptime: '99.8%'
    },
    features: ['Chatbot inteligente', 'Recomendações personalizadas', 'Análise de comportamento']
  },
  {
    id: 'hotel',
    title: 'Agente para Hotelaria',
    description: 'Gestão inteligente de hospedagem',
    price: 'R$ 299/mês',
    image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&q=80&w=500',
    metrics: {
      rating: 4.7,
      users: '1.8k+',
      uptime: '99.7%'
    },
    features: ['Check-in automatizado', 'Gestão de reservas', 'Atendimento 24/7']
  },
  {
    id: 'health',
    title: 'Agente para Saúde',
    description: 'Atendimento personalizado na área da saúde',
    price: 'R$ 349/mês',
    image: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&q=80&w=500',
    metrics: {
      rating: 4.9,
      users: '2.2k+',
      uptime: '99.9%'
    },
    features: ['Agendamento inteligente', 'Prontuário digital', 'Telemedicina integrada']
  },
  {
    id: 'clinic',
    title: 'Agente para Consultório',
    description: 'Organize sua agenda e pacientes',
    price: 'R$ 179/mês',
    image: 'https://images.unsplash.com/photo-1516549655169-df83a0774514?auto=format&fit=crop&q=80&w=500',
    metrics: {
      rating: 4.6,
      users: '1.5k+',
      uptime: '99.5%'
    },
    features: ['Agenda sincronizada', 'Histórico de pacientes', 'Faturamento integrado']
  },
  {
    id: 'custom',
    title: 'Agente Personalizado',
    description: 'Crie seu próprio agente',
    price: 'Sob consulta',
    image: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=500',
    metrics: {
      rating: 4.8,
      users: '500+',
      uptime: '99.9%'
    },
    features: ['Personalização completa', 'Suporte dedicado', 'API customizada']
  }
];

export default function Home({ isDark }: HomeProps) {
  return (
    <div className="min-h-screen pt-24 pb-12 pl-72 pr-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-12">
          <h1 className={`text-4xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
            Escolha o agente ideal para seu negócio
          </h1>
          <p className={`text-xl ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
            Soluções personalizadas para cada segmento
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {agents.map((agent) => (
            <Link
              key={agent.id}
              to={`/agent/${agent.id}`}
              className={`group relative overflow-hidden rounded-2xl ${
                isDark ? 'bg-[#1A1F2E]' : 'bg-white'
              } hover:shadow-xl transition-all duration-300`}
            >
              {/* Imagem de fundo com overlay gradiente */}
              <div className="relative h-48 overflow-hidden">
                <img
                  src={agent.image}
                  alt={agent.title}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
              </div>

              {/* Conteúdo */}
              <div className="p-6">
                <h3 className={`text-xl font-semibold mb-2 ${isDark ? 'text-white' : 'text-gray-900'}`}>
                  {agent.title}
                </h3>
                <p className={`mb-4 ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
                  {agent.description}
                </p>

                <div className="flex items-center gap-4 mb-4">
                  <div className="flex items-center gap-1">
                    <Star className={`w-4 h-4 ${isDark ? 'text-yellow-400' : 'text-yellow-500'}`} />
                    <span className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>{agent.metrics.rating}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Users className={`w-4 h-4 ${isDark ? 'text-purple-400' : 'text-purple-500'}`} />
                    <span className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>{agent.metrics.users}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Zap className={`w-4 h-4 ${isDark ? 'text-green-400' : 'text-green-500'}`} />
                    <span className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>{agent.metrics.uptime}</span>
                  </div>
                </div>

                <div className="space-y-2 mb-6">
                  {agent.features.map((feature, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-purple-500" />
                      <span className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>{feature}</span>
                    </div>
                  ))}
                </div>

                <div className="flex items-center justify-between">
                  <span className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>
                    {agent.price}
                  </span>
                  <button className="px-4 py-2 rounded-xl bg-purple-500 text-white font-medium hover:bg-purple-600 transition-colors duration-300">
                    Começar agora
                  </button>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}