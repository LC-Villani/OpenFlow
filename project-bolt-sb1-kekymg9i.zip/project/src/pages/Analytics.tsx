import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { BarChart3, ArrowRight, MessageSquare, Calendar, Zap, LineChart as ChartLine, Users, TrendingUp } from 'lucide-react';

interface AnalyticsProps {
  isDark: boolean;
}

interface Agent {
  id: number;
  name: string;
  type: string;
  createdAt: string;
}

export default function Analytics({ isDark }: AnalyticsProps) {
  const agents = JSON.parse(localStorage.getItem('agents') || '[]');

  if (agents.length === 0) {
    return (
      <div className="min-h-screen pt-24 pb-12 pl-72 pr-8">
        <div className="max-w-4xl mx-auto">
          <div className="flex flex-col items-center justify-center text-center">
            <div className={`w-20 h-20 ${isDark ? 'bg-purple-500/20' : 'bg-purple-100'} rounded-2xl flex items-center justify-center mb-6`}>
              <BarChart3 className={`w-10 h-10 ${isDark ? 'text-purple-400' : 'text-purple-500'}`} />
            </div>

            <h1 className={`text-3xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
              Analytics não disponível
            </h1>
            
            <p className={`text-lg mb-8 max-w-lg ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
              Para acessar o Analytics, você precisa ter pelo menos um agente SDR ativo em sua conta.
            </p>

            <Link
              to="/purchase"
              className="inline-flex items-center gap-2 px-6 py-3 bg-purple-500 text-white rounded-xl hover:bg-purple-600 transition-all duration-300 group"
            >
              <span>Adquirir um agente</span>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-24 pb-12 pl-72 pr-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-12">
          <h1 className={`text-4xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
            Analytics
          </h1>
          <p className={`text-xl ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
            Análise de desempenho dos seus agentes
          </p>
        </div>

        {/* Métricas Gerais */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className={`p-6 rounded-2xl ${isDark ? 'bg-[#1A1F2E]' : 'bg-white'}`}>
            <div className="flex items-center gap-4 mb-4">
              <div className={`w-12 h-12 rounded-xl ${isDark ? 'bg-purple-500/20' : 'bg-purple-100'} flex items-center justify-center`}>
                <Users className={`w-6 h-6 ${isDark ? 'text-purple-400' : 'text-purple-500'}`} />
              </div>
              <div>
                <p className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>Total de Agentes</p>
                <h3 className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>{agents.length}</h3>
              </div>
            </div>
          </div>

          <div className={`p-6 rounded-2xl ${isDark ? 'bg-[#1A1F2E]' : 'bg-white'}`}>
            <div className="flex items-center gap-4 mb-4">
              <div className={`w-12 h-12 rounded-xl ${isDark ? 'bg-green-500/20' : 'bg-green-100'} flex items-center justify-center`}>
                <Zap className={`w-6 h-6 ${isDark ? 'text-green-400' : 'text-green-500'}`} />
              </div>
              <div>
                <p className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>Taxa de Sucesso</p>
                <h3 className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>98.5%</h3>
              </div>
            </div>
          </div>

          <div className={`p-6 rounded-2xl ${isDark ? 'bg-[#1A1F2E]' : 'bg-white'}`}>
            <div className="flex items-center gap-4 mb-4">
              <div className={`w-12 h-12 rounded-xl ${isDark ? 'bg-blue-500/20' : 'bg-blue-100'} flex items-center justify-center`}>
                <ChartLine className={`w-6 h-6 ${isDark ? 'text-blue-400' : 'text-blue-500'}`} />
              </div>
              <div>
                <p className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>Conversões</p>
                <h3 className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>1.2k</h3>
              </div>
            </div>
          </div>

          <div className={`p-6 rounded-2xl ${isDark ? 'bg-[#1A1F2E]' : 'bg-white'}`}>
            <div className="flex items-center gap-4 mb-4">
              <div className={`w-12 h-12 rounded-xl ${isDark ? 'bg-yellow-500/20' : 'bg-yellow-100'} flex items-center justify-center`}>
                <TrendingUp className={`w-6 h-6 ${isDark ? 'text-yellow-400' : 'text-yellow-500'}`} />
              </div>
              <div>
                <p className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>Crescimento</p>
                <h3 className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>+24%</h3>
              </div>
            </div>
          </div>
        </div>

        {/* Lista de Agentes */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {agents.map((agent: Agent) => (
            <div
              key={agent.id}
              className={`group relative overflow-hidden rounded-2xl ${
                isDark ? 'bg-[#1A1F2E]' : 'bg-white'
              } hover:shadow-xl transition-all duration-300 p-6`}
            >
              <div className="flex items-center gap-4 mb-6">
                <div className={`w-12 h-12 rounded-xl ${isDark ? 'bg-purple-500/20' : 'bg-purple-100'} flex items-center justify-center`}>
                  <MessageSquare className={`w-6 h-6 ${isDark ? 'text-purple-400' : 'text-purple-500'}`} />
                </div>
                <div>
                  <h3 className={`text-xl font-semibold ${isDark ? 'text-white' : 'text-gray-900'}`}>
                    {agent.name}
                  </h3>
                  <p className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>
                    {agent.type}
                  </p>
                </div>
              </div>

              <div className="space-y-4">
                <div className={`p-4 rounded-xl ${isDark ? 'bg-[#232838]' : 'bg-purple-50'}`}>
                  <div className="flex items-center justify-between mb-2">
                    <span className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>Taxa de Resposta</span>
                    <span className={`font-semibold ${isDark ? 'text-white' : 'text-gray-900'}`}>98%</span>
                  </div>
                  <div className="h-2 bg-purple-200 rounded-full overflow-hidden">
                    <div className="h-full w-[98%] bg-purple-500 rounded-full" />
                  </div>
                </div>

                <div className={`p-4 rounded-xl ${isDark ? 'bg-[#232838]' : 'bg-purple-50'}`}>
                  <div className="flex items-center justify-between mb-2">
                    <span className={`text-sm ${isDark ? 'text-purple-300' : 'text-purple-600'}`}>Conversões</span>
                    <span className={`font-semibold ${isDark ? 'text-white' : 'text-gray-900'}`}>85%</span>
                  </div>
                  <div className="h-2 bg-purple-200 rounded-full overflow-hidden">
                    <div className="h-full w-[85%] bg-purple-500 rounded-full" />
                  </div>
                </div>

                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <Calendar className={`w-4 h-4 ${isDark ? 'text-purple-400' : 'text-purple-500'}`} />
                    <span className={isDark ? 'text-purple-300' : 'text-purple-600'}>
                      {new Date(agent.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Zap className={`w-4 h-4 ${isDark ? 'text-green-400' : 'text-green-500'}`} />
                    <span className={isDark ? 'text-purple-300' : 'text-purple-600'}>
                      Ativo
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}